/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "H:/ISEFILES/zhong/shuzizhong/miao.v";
static int ng1[] = {0, 0};
static int ng2[] = {6, 0};
static int ng3[] = {9, 0};
static unsigned int ng4[] = {1U, 0U};
static int ng5[] = {5, 0};



static void Always_25_0(char *t0)
{
    char t4[8];
    char t31[8];
    char t36[8];
    char t40[8];
    char t43[8];
    char t80[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;
    char *t30;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t37;
    char *t38;
    char *t39;
    char *t41;
    char *t42;
    char *t44;
    char *t45;
    char *t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    char *t52;
    char *t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    int t62;
    int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    char *t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    char *t76;
    char *t77;
    char *t78;
    char *t79;
    char *t81;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    unsigned int t86;
    unsigned int t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    unsigned int t92;
    unsigned int t93;

LAB0:    t1 = (t0 + 2688U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(25, ng0);
    t2 = (t0 + 3008);
    *((int *)t2) = 1;
    t3 = (t0 + 2720);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(26, ng0);

LAB5:    xsi_set_current_line(27, ng0);
    t5 = (t0 + 1208U);
    t6 = *((char **)t5);
    memset(t4, 0, 8);
    t5 = (t6 + 4);
    t7 = *((unsigned int *)t5);
    t8 = (~(t7));
    t9 = *((unsigned int *)t6);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB9;

LAB7:    if (*((unsigned int *)t5) == 0)
        goto LAB6;

LAB8:    t12 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t12) = 1;

LAB9:    t13 = (t4 + 4);
    t14 = (t6 + 4);
    t15 = *((unsigned int *)t6);
    t16 = (~(t15));
    *((unsigned int *)t4) = t16;
    *((unsigned int *)t13) = 0;
    if (*((unsigned int *)t14) != 0)
        goto LAB11;

LAB10:    t21 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t21 & 1U);
    t22 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t22 & 1U);
    t23 = (t4 + 4);
    t24 = *((unsigned int *)t23);
    t25 = (~(t24));
    t26 = *((unsigned int *)t4);
    t27 = (t26 & t25);
    t28 = (t27 != 0);
    if (t28 > 0)
        goto LAB12;

LAB13:    xsi_set_current_line(32, ng0);
    t2 = (t0 + 1608);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = ((char*)((ng2)));
    memset(t4, 0, 8);
    t12 = (t5 + 4);
    if (*((unsigned int *)t12) != 0)
        goto LAB17;

LAB16:    t13 = (t6 + 4);
    if (*((unsigned int *)t13) != 0)
        goto LAB17;

LAB20:    if (*((unsigned int *)t5) < *((unsigned int *)t6))
        goto LAB18;

LAB19:    memset(t31, 0, 8);
    t23 = (t4 + 4);
    t7 = *((unsigned int *)t23);
    t8 = (~(t7));
    t9 = *((unsigned int *)t4);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB21;

LAB22:    if (*((unsigned int *)t23) != 0)
        goto LAB23;

LAB24:    t30 = (t31 + 4);
    t15 = *((unsigned int *)t31);
    t16 = *((unsigned int *)t30);
    t17 = (t15 || t16);
    if (t17 > 0)
        goto LAB25;

LAB26:    memcpy(t43, t31, 8);

LAB27:    t70 = (t43 + 4);
    t71 = *((unsigned int *)t70);
    t72 = (~(t71));
    t73 = *((unsigned int *)t43);
    t74 = (t73 & t72);
    t75 = (t74 != 0);
    if (t75 > 0)
        goto LAB40;

LAB41:    xsi_set_current_line(33, ng0);
    t2 = (t0 + 1608);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = ((char*)((ng5)));
    memset(t4, 0, 8);
    t12 = (t5 + 4);
    if (*((unsigned int *)t12) != 0)
        goto LAB44;

LAB43:    t13 = (t6 + 4);
    if (*((unsigned int *)t13) != 0)
        goto LAB44;

LAB47:    if (*((unsigned int *)t5) < *((unsigned int *)t6))
        goto LAB45;

LAB46:    memset(t31, 0, 8);
    t23 = (t4 + 4);
    t7 = *((unsigned int *)t23);
    t8 = (~(t7));
    t9 = *((unsigned int *)t4);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB48;

LAB49:    if (*((unsigned int *)t23) != 0)
        goto LAB50;

LAB51:    t30 = (t31 + 4);
    t15 = *((unsigned int *)t31);
    t16 = *((unsigned int *)t30);
    t17 = (t15 || t16);
    if (t17 > 0)
        goto LAB52;

LAB53:    memcpy(t43, t31, 8);

LAB54:    t70 = (t43 + 4);
    t89 = *((unsigned int *)t70);
    t90 = (~(t89));
    t91 = *((unsigned int *)t43);
    t92 = (t91 & t90);
    t93 = (t92 != 0);
    if (t93 > 0)
        goto LAB66;

LAB67:    xsi_set_current_line(39, ng0);

LAB70:    xsi_set_current_line(40, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 1608);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 4, 0LL);
    xsi_set_current_line(41, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 1768);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 4, 0LL);

LAB68:
LAB42:
LAB14:    goto LAB2;

LAB6:    *((unsigned int *)t4) = 1;
    goto LAB9;

LAB11:    t17 = *((unsigned int *)t4);
    t18 = *((unsigned int *)t14);
    *((unsigned int *)t4) = (t17 | t18);
    t19 = *((unsigned int *)t13);
    t20 = *((unsigned int *)t14);
    *((unsigned int *)t13) = (t19 | t20);
    goto LAB10;

LAB12:    xsi_set_current_line(28, ng0);

LAB15:    xsi_set_current_line(29, ng0);
    t29 = ((char*)((ng1)));
    t30 = (t0 + 1608);
    xsi_vlogvar_wait_assign_value(t30, t29, 0, 0, 4, 0LL);
    xsi_set_current_line(30, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 1768);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 4, 0LL);
    goto LAB14;

LAB17:    t14 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t14) = 1;
    goto LAB19;

LAB18:    *((unsigned int *)t4) = 1;
    goto LAB19;

LAB21:    *((unsigned int *)t31) = 1;
    goto LAB24;

LAB23:    t29 = (t31 + 4);
    *((unsigned int *)t31) = 1;
    *((unsigned int *)t29) = 1;
    goto LAB24;

LAB25:    t32 = (t0 + 1768);
    t33 = (t32 + 56U);
    t34 = *((char **)t33);
    t35 = ((char*)((ng3)));
    memset(t36, 0, 8);
    t37 = (t34 + 4);
    if (*((unsigned int *)t37) != 0)
        goto LAB29;

LAB28:    t38 = (t35 + 4);
    if (*((unsigned int *)t38) != 0)
        goto LAB29;

LAB32:    if (*((unsigned int *)t34) < *((unsigned int *)t35))
        goto LAB30;

LAB31:    memset(t40, 0, 8);
    t41 = (t36 + 4);
    t18 = *((unsigned int *)t41);
    t19 = (~(t18));
    t20 = *((unsigned int *)t36);
    t21 = (t20 & t19);
    t22 = (t21 & 1U);
    if (t22 != 0)
        goto LAB33;

LAB34:    if (*((unsigned int *)t41) != 0)
        goto LAB35;

LAB36:    t24 = *((unsigned int *)t31);
    t25 = *((unsigned int *)t40);
    t26 = (t24 & t25);
    *((unsigned int *)t43) = t26;
    t44 = (t31 + 4);
    t45 = (t40 + 4);
    t46 = (t43 + 4);
    t27 = *((unsigned int *)t44);
    t28 = *((unsigned int *)t45);
    t47 = (t27 | t28);
    *((unsigned int *)t46) = t47;
    t48 = *((unsigned int *)t46);
    t49 = (t48 != 0);
    if (t49 == 1)
        goto LAB37;

LAB38:
LAB39:    goto LAB27;

LAB29:    t39 = (t36 + 4);
    *((unsigned int *)t36) = 1;
    *((unsigned int *)t39) = 1;
    goto LAB31;

LAB30:    *((unsigned int *)t36) = 1;
    goto LAB31;

LAB33:    *((unsigned int *)t40) = 1;
    goto LAB36;

LAB35:    t42 = (t40 + 4);
    *((unsigned int *)t40) = 1;
    *((unsigned int *)t42) = 1;
    goto LAB36;

LAB37:    t50 = *((unsigned int *)t43);
    t51 = *((unsigned int *)t46);
    *((unsigned int *)t43) = (t50 | t51);
    t52 = (t31 + 4);
    t53 = (t40 + 4);
    t54 = *((unsigned int *)t31);
    t55 = (~(t54));
    t56 = *((unsigned int *)t52);
    t57 = (~(t56));
    t58 = *((unsigned int *)t40);
    t59 = (~(t58));
    t60 = *((unsigned int *)t53);
    t61 = (~(t60));
    t62 = (t55 & t57);
    t63 = (t59 & t61);
    t64 = (~(t62));
    t65 = (~(t63));
    t66 = *((unsigned int *)t46);
    *((unsigned int *)t46) = (t66 & t64);
    t67 = *((unsigned int *)t46);
    *((unsigned int *)t46) = (t67 & t65);
    t68 = *((unsigned int *)t43);
    *((unsigned int *)t43) = (t68 & t64);
    t69 = *((unsigned int *)t43);
    *((unsigned int *)t43) = (t69 & t65);
    goto LAB39;

LAB40:    xsi_set_current_line(32, ng0);
    t76 = (t0 + 1768);
    t77 = (t76 + 56U);
    t78 = *((char **)t77);
    t79 = ((char*)((ng4)));
    memset(t80, 0, 8);
    xsi_vlog_unsigned_add(t80, 4, t78, 4, t79, 4);
    t81 = (t0 + 1768);
    xsi_vlogvar_wait_assign_value(t81, t80, 0, 0, 4, 0LL);
    goto LAB42;

LAB44:    t14 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t14) = 1;
    goto LAB46;

LAB45:    *((unsigned int *)t4) = 1;
    goto LAB46;

LAB48:    *((unsigned int *)t31) = 1;
    goto LAB51;

LAB50:    t29 = (t31 + 4);
    *((unsigned int *)t31) = 1;
    *((unsigned int *)t29) = 1;
    goto LAB51;

LAB52:    t32 = (t0 + 1768);
    t33 = (t32 + 56U);
    t34 = *((char **)t33);
    t35 = ((char*)((ng3)));
    memset(t36, 0, 8);
    t37 = (t34 + 4);
    t38 = (t35 + 4);
    t18 = *((unsigned int *)t34);
    t19 = *((unsigned int *)t35);
    t20 = (t18 ^ t19);
    t21 = *((unsigned int *)t37);
    t22 = *((unsigned int *)t38);
    t24 = (t21 ^ t22);
    t25 = (t20 | t24);
    t26 = *((unsigned int *)t37);
    t27 = *((unsigned int *)t38);
    t28 = (t26 | t27);
    t47 = (~(t28));
    t48 = (t25 & t47);
    if (t48 != 0)
        goto LAB58;

LAB55:    if (t28 != 0)
        goto LAB57;

LAB56:    *((unsigned int *)t36) = 1;

LAB58:    memset(t40, 0, 8);
    t41 = (t36 + 4);
    t49 = *((unsigned int *)t41);
    t50 = (~(t49));
    t51 = *((unsigned int *)t36);
    t54 = (t51 & t50);
    t55 = (t54 & 1U);
    if (t55 != 0)
        goto LAB59;

LAB60:    if (*((unsigned int *)t41) != 0)
        goto LAB61;

LAB62:    t56 = *((unsigned int *)t31);
    t57 = *((unsigned int *)t40);
    t58 = (t56 & t57);
    *((unsigned int *)t43) = t58;
    t44 = (t31 + 4);
    t45 = (t40 + 4);
    t46 = (t43 + 4);
    t59 = *((unsigned int *)t44);
    t60 = *((unsigned int *)t45);
    t61 = (t59 | t60);
    *((unsigned int *)t46) = t61;
    t64 = *((unsigned int *)t46);
    t65 = (t64 != 0);
    if (t65 == 1)
        goto LAB63;

LAB64:
LAB65:    goto LAB54;

LAB57:    t39 = (t36 + 4);
    *((unsigned int *)t36) = 1;
    *((unsigned int *)t39) = 1;
    goto LAB58;

LAB59:    *((unsigned int *)t40) = 1;
    goto LAB62;

LAB61:    t42 = (t40 + 4);
    *((unsigned int *)t40) = 1;
    *((unsigned int *)t42) = 1;
    goto LAB62;

LAB63:    t66 = *((unsigned int *)t43);
    t67 = *((unsigned int *)t46);
    *((unsigned int *)t43) = (t66 | t67);
    t52 = (t31 + 4);
    t53 = (t40 + 4);
    t68 = *((unsigned int *)t31);
    t69 = (~(t68));
    t71 = *((unsigned int *)t52);
    t72 = (~(t71));
    t73 = *((unsigned int *)t40);
    t74 = (~(t73));
    t75 = *((unsigned int *)t53);
    t82 = (~(t75));
    t62 = (t69 & t72);
    t63 = (t74 & t82);
    t83 = (~(t62));
    t84 = (~(t63));
    t85 = *((unsigned int *)t46);
    *((unsigned int *)t46) = (t85 & t83);
    t86 = *((unsigned int *)t46);
    *((unsigned int *)t46) = (t86 & t84);
    t87 = *((unsigned int *)t43);
    *((unsigned int *)t43) = (t87 & t83);
    t88 = *((unsigned int *)t43);
    *((unsigned int *)t43) = (t88 & t84);
    goto LAB65;

LAB66:    xsi_set_current_line(34, ng0);

LAB69:    xsi_set_current_line(35, ng0);
    t76 = ((char*)((ng1)));
    t77 = (t0 + 1768);
    xsi_vlogvar_wait_assign_value(t77, t76, 0, 0, 4, 0LL);
    xsi_set_current_line(36, ng0);
    t2 = (t0 + 1608);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = ((char*)((ng4)));
    memset(t4, 0, 8);
    xsi_vlog_unsigned_add(t4, 4, t5, 4, t6, 4);
    t12 = (t0 + 1608);
    xsi_vlogvar_wait_assign_value(t12, t4, 0, 0, 4, 0LL);
    goto LAB68;

}


extern void work_m_00000000000531319523_2697162249_init()
{
	static char *pe[] = {(void *)Always_25_0};
	xsi_register_didat("work_m_00000000000531319523_2697162249", "isim/testclock_isim_beh.exe.sim/work/m_00000000000531319523_2697162249.didat");
	xsi_register_executes(pe);
}
