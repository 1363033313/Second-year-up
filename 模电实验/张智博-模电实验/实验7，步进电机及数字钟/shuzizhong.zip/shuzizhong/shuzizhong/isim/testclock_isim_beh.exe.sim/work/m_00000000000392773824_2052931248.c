/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "H:/ISEFILES/zhong/shuzizhong/alarm.v";
static int ng1[] = {0, 0};
static int ng2[] = {199, 0};
static int ng3[] = {399, 0};
static int ng4[] = {599, 0};
static int ng5[] = {799, 0};
static int ng6[] = {999, 0};
static int ng7[] = {1199, 0};
static unsigned int ng8[] = {1U, 0U};
static int ng9[] = {1599, 0};



static void Always_27_0(char *t0)
{
    char t4[8];
    char t23[8];
    char t36[8];
    char t55[8];
    char t63[8];
    char t91[8];
    char t104[8];
    char t123[8];
    char t131[8];
    char t159[8];
    char t172[8];
    char t191[8];
    char t199[8];
    char t227[8];
    char t243[8];
    char t258[8];
    char t266[8];
    char t294[8];
    char t310[8];
    char t325[8];
    char t333[8];
    char t381[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    char *t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    char *t30;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    char *t37;
    char *t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    char *t44;
    char *t45;
    char *t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    char *t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    char *t62;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    char *t67;
    char *t68;
    char *t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    char *t77;
    char *t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    int t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    int t86;
    unsigned int t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    char *t92;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    unsigned int t97;
    char *t98;
    char *t99;
    unsigned int t100;
    unsigned int t101;
    unsigned int t102;
    unsigned int t103;
    char *t105;
    char *t106;
    unsigned int t107;
    unsigned int t108;
    unsigned int t109;
    unsigned int t110;
    unsigned int t111;
    char *t112;
    char *t113;
    char *t114;
    unsigned int t115;
    unsigned int t116;
    unsigned int t117;
    unsigned int t118;
    unsigned int t119;
    unsigned int t120;
    unsigned int t121;
    unsigned int t122;
    char *t124;
    unsigned int t125;
    unsigned int t126;
    unsigned int t127;
    unsigned int t128;
    unsigned int t129;
    char *t130;
    unsigned int t132;
    unsigned int t133;
    unsigned int t134;
    char *t135;
    char *t136;
    char *t137;
    unsigned int t138;
    unsigned int t139;
    unsigned int t140;
    unsigned int t141;
    unsigned int t142;
    unsigned int t143;
    unsigned int t144;
    char *t145;
    char *t146;
    unsigned int t147;
    unsigned int t148;
    unsigned int t149;
    int t150;
    unsigned int t151;
    unsigned int t152;
    unsigned int t153;
    int t154;
    unsigned int t155;
    unsigned int t156;
    unsigned int t157;
    unsigned int t158;
    char *t160;
    unsigned int t161;
    unsigned int t162;
    unsigned int t163;
    unsigned int t164;
    unsigned int t165;
    char *t166;
    char *t167;
    unsigned int t168;
    unsigned int t169;
    unsigned int t170;
    unsigned int t171;
    char *t173;
    char *t174;
    unsigned int t175;
    unsigned int t176;
    unsigned int t177;
    unsigned int t178;
    unsigned int t179;
    char *t180;
    char *t181;
    char *t182;
    unsigned int t183;
    unsigned int t184;
    unsigned int t185;
    unsigned int t186;
    unsigned int t187;
    unsigned int t188;
    unsigned int t189;
    unsigned int t190;
    char *t192;
    unsigned int t193;
    unsigned int t194;
    unsigned int t195;
    unsigned int t196;
    unsigned int t197;
    char *t198;
    unsigned int t200;
    unsigned int t201;
    unsigned int t202;
    char *t203;
    char *t204;
    char *t205;
    unsigned int t206;
    unsigned int t207;
    unsigned int t208;
    unsigned int t209;
    unsigned int t210;
    unsigned int t211;
    unsigned int t212;
    char *t213;
    char *t214;
    unsigned int t215;
    unsigned int t216;
    unsigned int t217;
    int t218;
    unsigned int t219;
    unsigned int t220;
    unsigned int t221;
    int t222;
    unsigned int t223;
    unsigned int t224;
    unsigned int t225;
    unsigned int t226;
    char *t228;
    unsigned int t229;
    unsigned int t230;
    unsigned int t231;
    unsigned int t232;
    unsigned int t233;
    char *t234;
    char *t235;
    unsigned int t236;
    unsigned int t237;
    unsigned int t238;
    unsigned int t239;
    char *t240;
    char *t241;
    char *t242;
    char *t244;
    unsigned int t245;
    unsigned int t246;
    unsigned int t247;
    unsigned int t248;
    unsigned int t249;
    unsigned int t250;
    unsigned int t251;
    unsigned int t252;
    unsigned int t253;
    unsigned int t254;
    unsigned int t255;
    unsigned int t256;
    char *t257;
    char *t259;
    unsigned int t260;
    unsigned int t261;
    unsigned int t262;
    unsigned int t263;
    unsigned int t264;
    char *t265;
    unsigned int t267;
    unsigned int t268;
    unsigned int t269;
    char *t270;
    char *t271;
    char *t272;
    unsigned int t273;
    unsigned int t274;
    unsigned int t275;
    unsigned int t276;
    unsigned int t277;
    unsigned int t278;
    unsigned int t279;
    char *t280;
    char *t281;
    unsigned int t282;
    unsigned int t283;
    unsigned int t284;
    int t285;
    unsigned int t286;
    unsigned int t287;
    unsigned int t288;
    int t289;
    unsigned int t290;
    unsigned int t291;
    unsigned int t292;
    unsigned int t293;
    char *t295;
    unsigned int t296;
    unsigned int t297;
    unsigned int t298;
    unsigned int t299;
    unsigned int t300;
    char *t301;
    char *t302;
    unsigned int t303;
    unsigned int t304;
    unsigned int t305;
    unsigned int t306;
    char *t307;
    char *t308;
    char *t309;
    char *t311;
    unsigned int t312;
    unsigned int t313;
    unsigned int t314;
    unsigned int t315;
    unsigned int t316;
    unsigned int t317;
    unsigned int t318;
    unsigned int t319;
    unsigned int t320;
    unsigned int t321;
    unsigned int t322;
    unsigned int t323;
    char *t324;
    char *t326;
    unsigned int t327;
    unsigned int t328;
    unsigned int t329;
    unsigned int t330;
    unsigned int t331;
    char *t332;
    unsigned int t334;
    unsigned int t335;
    unsigned int t336;
    char *t337;
    char *t338;
    char *t339;
    unsigned int t340;
    unsigned int t341;
    unsigned int t342;
    unsigned int t343;
    unsigned int t344;
    unsigned int t345;
    unsigned int t346;
    char *t347;
    char *t348;
    unsigned int t349;
    unsigned int t350;
    unsigned int t351;
    int t352;
    unsigned int t353;
    unsigned int t354;
    unsigned int t355;
    int t356;
    unsigned int t357;
    unsigned int t358;
    unsigned int t359;
    unsigned int t360;
    char *t361;
    unsigned int t362;
    unsigned int t363;
    unsigned int t364;
    unsigned int t365;
    unsigned int t366;
    char *t367;
    char *t368;
    char *t369;
    char *t370;
    char *t371;
    char *t372;
    char *t373;
    char *t374;
    char *t375;
    char *t376;
    char *t377;
    char *t378;
    char *t379;
    char *t380;
    char *t382;

LAB0:    t1 = (t0 + 3808U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(27, ng0);
    t2 = (t0 + 4128);
    *((int *)t2) = 1;
    t3 = (t0 + 3840);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(28, ng0);

LAB5:    xsi_set_current_line(29, ng0);
    t5 = (t0 + 1208U);
    t6 = *((char **)t5);
    memset(t4, 0, 8);
    t5 = (t6 + 4);
    t7 = *((unsigned int *)t5);
    t8 = (~(t7));
    t9 = *((unsigned int *)t6);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB9;

LAB7:    if (*((unsigned int *)t5) == 0)
        goto LAB6;

LAB8:    t12 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t12) = 1;

LAB9:    t13 = (t4 + 4);
    t14 = (t6 + 4);
    t15 = *((unsigned int *)t6);
    t16 = (~(t15));
    *((unsigned int *)t4) = t16;
    *((unsigned int *)t13) = 0;
    if (*((unsigned int *)t14) != 0)
        goto LAB11;

LAB10:    t21 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t21 & 1U);
    t22 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t22 & 1U);
    memset(t23, 0, 8);
    t24 = (t4 + 4);
    t25 = *((unsigned int *)t24);
    t26 = (~(t25));
    t27 = *((unsigned int *)t4);
    t28 = (t27 & t26);
    t29 = (t28 & 1U);
    if (t29 != 0)
        goto LAB12;

LAB13:    if (*((unsigned int *)t24) != 0)
        goto LAB14;

LAB15:    t31 = (t23 + 4);
    t32 = *((unsigned int *)t23);
    t33 = (!(t32));
    t34 = *((unsigned int *)t31);
    t35 = (t33 || t34);
    if (t35 > 0)
        goto LAB16;

LAB17:    memcpy(t63, t23, 8);

LAB18:    memset(t91, 0, 8);
    t92 = (t63 + 4);
    t93 = *((unsigned int *)t92);
    t94 = (~(t93));
    t95 = *((unsigned int *)t63);
    t96 = (t95 & t94);
    t97 = (t96 & 1U);
    if (t97 != 0)
        goto LAB32;

LAB33:    if (*((unsigned int *)t92) != 0)
        goto LAB34;

LAB35:    t99 = (t91 + 4);
    t100 = *((unsigned int *)t91);
    t101 = (!(t100));
    t102 = *((unsigned int *)t99);
    t103 = (t101 || t102);
    if (t103 > 0)
        goto LAB36;

LAB37:    memcpy(t131, t91, 8);

LAB38:    memset(t159, 0, 8);
    t160 = (t131 + 4);
    t161 = *((unsigned int *)t160);
    t162 = (~(t161));
    t163 = *((unsigned int *)t131);
    t164 = (t163 & t162);
    t165 = (t164 & 1U);
    if (t165 != 0)
        goto LAB52;

LAB53:    if (*((unsigned int *)t160) != 0)
        goto LAB54;

LAB55:    t167 = (t159 + 4);
    t168 = *((unsigned int *)t159);
    t169 = (!(t168));
    t170 = *((unsigned int *)t167);
    t171 = (t169 || t170);
    if (t171 > 0)
        goto LAB56;

LAB57:    memcpy(t199, t159, 8);

LAB58:    memset(t227, 0, 8);
    t228 = (t199 + 4);
    t229 = *((unsigned int *)t228);
    t230 = (~(t229));
    t231 = *((unsigned int *)t199);
    t232 = (t231 & t230);
    t233 = (t232 & 1U);
    if (t233 != 0)
        goto LAB72;

LAB73:    if (*((unsigned int *)t228) != 0)
        goto LAB74;

LAB75:    t235 = (t227 + 4);
    t236 = *((unsigned int *)t227);
    t237 = (!(t236));
    t238 = *((unsigned int *)t235);
    t239 = (t237 || t238);
    if (t239 > 0)
        goto LAB76;

LAB77:    memcpy(t266, t227, 8);

LAB78:    memset(t294, 0, 8);
    t295 = (t266 + 4);
    t296 = *((unsigned int *)t295);
    t297 = (~(t296));
    t298 = *((unsigned int *)t266);
    t299 = (t298 & t297);
    t300 = (t299 & 1U);
    if (t300 != 0)
        goto LAB90;

LAB91:    if (*((unsigned int *)t295) != 0)
        goto LAB92;

LAB93:    t302 = (t294 + 4);
    t303 = *((unsigned int *)t294);
    t304 = (!(t303));
    t305 = *((unsigned int *)t302);
    t306 = (t304 || t305);
    if (t306 > 0)
        goto LAB94;

LAB95:    memcpy(t333, t294, 8);

LAB96:    t361 = (t333 + 4);
    t362 = *((unsigned int *)t361);
    t363 = (~(t362));
    t364 = *((unsigned int *)t333);
    t365 = (t364 & t363);
    t366 = (t365 != 0);
    if (t366 > 0)
        goto LAB108;

LAB109:    xsi_set_current_line(34, ng0);
    t2 = (t0 + 2888);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = ((char*)((ng2)));
    memset(t4, 0, 8);
    t12 = (t5 + 4);
    t13 = (t6 + 4);
    t7 = *((unsigned int *)t5);
    t8 = *((unsigned int *)t6);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t12);
    t11 = *((unsigned int *)t13);
    t15 = (t10 ^ t11);
    t16 = (t9 | t15);
    t17 = *((unsigned int *)t12);
    t18 = *((unsigned int *)t13);
    t19 = (t17 | t18);
    t20 = (~(t19));
    t21 = (t16 & t20);
    if (t21 != 0)
        goto LAB115;

LAB112:    if (t19 != 0)
        goto LAB114;

LAB113:    *((unsigned int *)t4) = 1;

LAB115:    memset(t23, 0, 8);
    t24 = (t4 + 4);
    t22 = *((unsigned int *)t24);
    t25 = (~(t22));
    t26 = *((unsigned int *)t4);
    t27 = (t26 & t25);
    t28 = (t27 & 1U);
    if (t28 != 0)
        goto LAB116;

LAB117:    if (*((unsigned int *)t24) != 0)
        goto LAB118;

LAB119:    t31 = (t23 + 4);
    t29 = *((unsigned int *)t23);
    t32 = (!(t29));
    t33 = *((unsigned int *)t31);
    t34 = (t32 || t33);
    if (t34 > 0)
        goto LAB120;

LAB121:    memcpy(t63, t23, 8);

LAB122:    memset(t91, 0, 8);
    t99 = (t63 + 4);
    t89 = *((unsigned int *)t99);
    t90 = (~(t89));
    t93 = *((unsigned int *)t63);
    t94 = (t93 & t90);
    t95 = (t94 & 1U);
    if (t95 != 0)
        goto LAB134;

LAB135:    if (*((unsigned int *)t99) != 0)
        goto LAB136;

LAB137:    t106 = (t91 + 4);
    t96 = *((unsigned int *)t91);
    t97 = (!(t96));
    t100 = *((unsigned int *)t106);
    t101 = (t97 || t100);
    if (t101 > 0)
        goto LAB138;

LAB139:    memcpy(t131, t91, 8);

LAB140:    memset(t159, 0, 8);
    t174 = (t131 + 4);
    t156 = *((unsigned int *)t174);
    t157 = (~(t156));
    t158 = *((unsigned int *)t131);
    t161 = (t158 & t157);
    t162 = (t161 & 1U);
    if (t162 != 0)
        goto LAB152;

LAB153:    if (*((unsigned int *)t174) != 0)
        goto LAB154;

LAB155:    t181 = (t159 + 4);
    t163 = *((unsigned int *)t159);
    t164 = (!(t163));
    t165 = *((unsigned int *)t181);
    t168 = (t164 || t165);
    if (t168 > 0)
        goto LAB156;

LAB157:    memcpy(t199, t159, 8);

LAB158:    memset(t227, 0, 8);
    t244 = (t199 + 4);
    t223 = *((unsigned int *)t244);
    t224 = (~(t223));
    t225 = *((unsigned int *)t199);
    t226 = (t225 & t224);
    t229 = (t226 & 1U);
    if (t229 != 0)
        goto LAB170;

LAB171:    if (*((unsigned int *)t244) != 0)
        goto LAB172;

LAB173:    t259 = (t227 + 4);
    t230 = *((unsigned int *)t227);
    t231 = (!(t230));
    t232 = *((unsigned int *)t259);
    t233 = (t231 || t232);
    if (t233 > 0)
        goto LAB174;

LAB175:    memcpy(t266, t227, 8);

LAB176:    memset(t294, 0, 8);
    t326 = (t266 + 4);
    t290 = *((unsigned int *)t326);
    t291 = (~(t290));
    t292 = *((unsigned int *)t266);
    t293 = (t292 & t291);
    t296 = (t293 & 1U);
    if (t296 != 0)
        goto LAB188;

LAB189:    if (*((unsigned int *)t326) != 0)
        goto LAB190;

LAB191:    t337 = (t294 + 4);
    t297 = *((unsigned int *)t294);
    t298 = (!(t297));
    t299 = *((unsigned int *)t337);
    t300 = (t298 || t299);
    if (t300 > 0)
        goto LAB192;

LAB193:    memcpy(t333, t294, 8);

LAB194:    t376 = (t333 + 4);
    t357 = *((unsigned int *)t376);
    t358 = (~(t357));
    t359 = *((unsigned int *)t333);
    t360 = (t359 & t358);
    t362 = (t360 != 0);
    if (t362 > 0)
        goto LAB206;

LAB207:    xsi_set_current_line(39, ng0);
    t2 = (t0 + 2888);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = ((char*)((ng9)));
    memset(t4, 0, 8);
    t12 = (t5 + 4);
    t13 = (t6 + 4);
    t7 = *((unsigned int *)t5);
    t8 = *((unsigned int *)t6);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t12);
    t11 = *((unsigned int *)t13);
    t15 = (t10 ^ t11);
    t16 = (t9 | t15);
    t17 = *((unsigned int *)t12);
    t18 = *((unsigned int *)t13);
    t19 = (t17 | t18);
    t20 = (~(t19));
    t21 = (t16 & t20);
    if (t21 != 0)
        goto LAB219;

LAB216:    if (t19 != 0)
        goto LAB218;

LAB217:    *((unsigned int *)t4) = 1;

LAB219:    t24 = (t4 + 4);
    t22 = *((unsigned int *)t24);
    t25 = (~(t22));
    t26 = *((unsigned int *)t4);
    t27 = (t26 & t25);
    t28 = (t27 != 0);
    if (t28 > 0)
        goto LAB220;

LAB221:    xsi_set_current_line(40, ng0);
    t2 = (t0 + 2888);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = ((char*)((ng8)));
    memset(t4, 0, 8);
    xsi_vlog_unsigned_add(t4, 11, t5, 11, t6, 11);
    t12 = (t0 + 2888);
    xsi_vlogvar_wait_assign_value(t12, t4, 0, 0, 11, 0LL);

LAB222:
LAB208:
LAB110:    goto LAB2;

LAB6:    *((unsigned int *)t4) = 1;
    goto LAB9;

LAB11:    t17 = *((unsigned int *)t4);
    t18 = *((unsigned int *)t14);
    *((unsigned int *)t4) = (t17 | t18);
    t19 = *((unsigned int *)t13);
    t20 = *((unsigned int *)t14);
    *((unsigned int *)t13) = (t19 | t20);
    goto LAB10;

LAB12:    *((unsigned int *)t23) = 1;
    goto LAB15;

LAB14:    t30 = (t23 + 4);
    *((unsigned int *)t23) = 1;
    *((unsigned int *)t30) = 1;
    goto LAB15;

LAB16:    t37 = (t0 + 1368U);
    t38 = *((char **)t37);
    memset(t36, 0, 8);
    t37 = (t38 + 4);
    t39 = *((unsigned int *)t37);
    t40 = (~(t39));
    t41 = *((unsigned int *)t38);
    t42 = (t41 & t40);
    t43 = (t42 & 1U);
    if (t43 != 0)
        goto LAB22;

LAB20:    if (*((unsigned int *)t37) == 0)
        goto LAB19;

LAB21:    t44 = (t36 + 4);
    *((unsigned int *)t36) = 1;
    *((unsigned int *)t44) = 1;

LAB22:    t45 = (t36 + 4);
    t46 = (t38 + 4);
    t47 = *((unsigned int *)t38);
    t48 = (~(t47));
    *((unsigned int *)t36) = t48;
    *((unsigned int *)t45) = 0;
    if (*((unsigned int *)t46) != 0)
        goto LAB24;

LAB23:    t53 = *((unsigned int *)t36);
    *((unsigned int *)t36) = (t53 & 1U);
    t54 = *((unsigned int *)t45);
    *((unsigned int *)t45) = (t54 & 1U);
    memset(t55, 0, 8);
    t56 = (t36 + 4);
    t57 = *((unsigned int *)t56);
    t58 = (~(t57));
    t59 = *((unsigned int *)t36);
    t60 = (t59 & t58);
    t61 = (t60 & 1U);
    if (t61 != 0)
        goto LAB25;

LAB26:    if (*((unsigned int *)t56) != 0)
        goto LAB27;

LAB28:    t64 = *((unsigned int *)t23);
    t65 = *((unsigned int *)t55);
    t66 = (t64 | t65);
    *((unsigned int *)t63) = t66;
    t67 = (t23 + 4);
    t68 = (t55 + 4);
    t69 = (t63 + 4);
    t70 = *((unsigned int *)t67);
    t71 = *((unsigned int *)t68);
    t72 = (t70 | t71);
    *((unsigned int *)t69) = t72;
    t73 = *((unsigned int *)t69);
    t74 = (t73 != 0);
    if (t74 == 1)
        goto LAB29;

LAB30:
LAB31:    goto LAB18;

LAB19:    *((unsigned int *)t36) = 1;
    goto LAB22;

LAB24:    t49 = *((unsigned int *)t36);
    t50 = *((unsigned int *)t46);
    *((unsigned int *)t36) = (t49 | t50);
    t51 = *((unsigned int *)t45);
    t52 = *((unsigned int *)t46);
    *((unsigned int *)t45) = (t51 | t52);
    goto LAB23;

LAB25:    *((unsigned int *)t55) = 1;
    goto LAB28;

LAB27:    t62 = (t55 + 4);
    *((unsigned int *)t55) = 1;
    *((unsigned int *)t62) = 1;
    goto LAB28;

LAB29:    t75 = *((unsigned int *)t63);
    t76 = *((unsigned int *)t69);
    *((unsigned int *)t63) = (t75 | t76);
    t77 = (t23 + 4);
    t78 = (t55 + 4);
    t79 = *((unsigned int *)t77);
    t80 = (~(t79));
    t81 = *((unsigned int *)t23);
    t82 = (t81 & t80);
    t83 = *((unsigned int *)t78);
    t84 = (~(t83));
    t85 = *((unsigned int *)t55);
    t86 = (t85 & t84);
    t87 = (~(t82));
    t88 = (~(t86));
    t89 = *((unsigned int *)t69);
    *((unsigned int *)t69) = (t89 & t87);
    t90 = *((unsigned int *)t69);
    *((unsigned int *)t69) = (t90 & t88);
    goto LAB31;

LAB32:    *((unsigned int *)t91) = 1;
    goto LAB35;

LAB34:    t98 = (t91 + 4);
    *((unsigned int *)t91) = 1;
    *((unsigned int *)t98) = 1;
    goto LAB35;

LAB36:    t105 = (t0 + 1528U);
    t106 = *((char **)t105);
    memset(t104, 0, 8);
    t105 = (t106 + 4);
    t107 = *((unsigned int *)t105);
    t108 = (~(t107));
    t109 = *((unsigned int *)t106);
    t110 = (t109 & t108);
    t111 = (t110 & 1U);
    if (t111 != 0)
        goto LAB42;

LAB40:    if (*((unsigned int *)t105) == 0)
        goto LAB39;

LAB41:    t112 = (t104 + 4);
    *((unsigned int *)t104) = 1;
    *((unsigned int *)t112) = 1;

LAB42:    t113 = (t104 + 4);
    t114 = (t106 + 4);
    t115 = *((unsigned int *)t106);
    t116 = (~(t115));
    *((unsigned int *)t104) = t116;
    *((unsigned int *)t113) = 0;
    if (*((unsigned int *)t114) != 0)
        goto LAB44;

LAB43:    t121 = *((unsigned int *)t104);
    *((unsigned int *)t104) = (t121 & 1U);
    t122 = *((unsigned int *)t113);
    *((unsigned int *)t113) = (t122 & 1U);
    memset(t123, 0, 8);
    t124 = (t104 + 4);
    t125 = *((unsigned int *)t124);
    t126 = (~(t125));
    t127 = *((unsigned int *)t104);
    t128 = (t127 & t126);
    t129 = (t128 & 1U);
    if (t129 != 0)
        goto LAB45;

LAB46:    if (*((unsigned int *)t124) != 0)
        goto LAB47;

LAB48:    t132 = *((unsigned int *)t91);
    t133 = *((unsigned int *)t123);
    t134 = (t132 | t133);
    *((unsigned int *)t131) = t134;
    t135 = (t91 + 4);
    t136 = (t123 + 4);
    t137 = (t131 + 4);
    t138 = *((unsigned int *)t135);
    t139 = *((unsigned int *)t136);
    t140 = (t138 | t139);
    *((unsigned int *)t137) = t140;
    t141 = *((unsigned int *)t137);
    t142 = (t141 != 0);
    if (t142 == 1)
        goto LAB49;

LAB50:
LAB51:    goto LAB38;

LAB39:    *((unsigned int *)t104) = 1;
    goto LAB42;

LAB44:    t117 = *((unsigned int *)t104);
    t118 = *((unsigned int *)t114);
    *((unsigned int *)t104) = (t117 | t118);
    t119 = *((unsigned int *)t113);
    t120 = *((unsigned int *)t114);
    *((unsigned int *)t113) = (t119 | t120);
    goto LAB43;

LAB45:    *((unsigned int *)t123) = 1;
    goto LAB48;

LAB47:    t130 = (t123 + 4);
    *((unsigned int *)t123) = 1;
    *((unsigned int *)t130) = 1;
    goto LAB48;

LAB49:    t143 = *((unsigned int *)t131);
    t144 = *((unsigned int *)t137);
    *((unsigned int *)t131) = (t143 | t144);
    t145 = (t91 + 4);
    t146 = (t123 + 4);
    t147 = *((unsigned int *)t145);
    t148 = (~(t147));
    t149 = *((unsigned int *)t91);
    t150 = (t149 & t148);
    t151 = *((unsigned int *)t146);
    t152 = (~(t151));
    t153 = *((unsigned int *)t123);
    t154 = (t153 & t152);
    t155 = (~(t150));
    t156 = (~(t154));
    t157 = *((unsigned int *)t137);
    *((unsigned int *)t137) = (t157 & t155);
    t158 = *((unsigned int *)t137);
    *((unsigned int *)t137) = (t158 & t156);
    goto LAB51;

LAB52:    *((unsigned int *)t159) = 1;
    goto LAB55;

LAB54:    t166 = (t159 + 4);
    *((unsigned int *)t159) = 1;
    *((unsigned int *)t166) = 1;
    goto LAB55;

LAB56:    t173 = (t0 + 1688U);
    t174 = *((char **)t173);
    memset(t172, 0, 8);
    t173 = (t174 + 4);
    t175 = *((unsigned int *)t173);
    t176 = (~(t175));
    t177 = *((unsigned int *)t174);
    t178 = (t177 & t176);
    t179 = (t178 & 1U);
    if (t179 != 0)
        goto LAB62;

LAB60:    if (*((unsigned int *)t173) == 0)
        goto LAB59;

LAB61:    t180 = (t172 + 4);
    *((unsigned int *)t172) = 1;
    *((unsigned int *)t180) = 1;

LAB62:    t181 = (t172 + 4);
    t182 = (t174 + 4);
    t183 = *((unsigned int *)t174);
    t184 = (~(t183));
    *((unsigned int *)t172) = t184;
    *((unsigned int *)t181) = 0;
    if (*((unsigned int *)t182) != 0)
        goto LAB64;

LAB63:    t189 = *((unsigned int *)t172);
    *((unsigned int *)t172) = (t189 & 1U);
    t190 = *((unsigned int *)t181);
    *((unsigned int *)t181) = (t190 & 1U);
    memset(t191, 0, 8);
    t192 = (t172 + 4);
    t193 = *((unsigned int *)t192);
    t194 = (~(t193));
    t195 = *((unsigned int *)t172);
    t196 = (t195 & t194);
    t197 = (t196 & 1U);
    if (t197 != 0)
        goto LAB65;

LAB66:    if (*((unsigned int *)t192) != 0)
        goto LAB67;

LAB68:    t200 = *((unsigned int *)t159);
    t201 = *((unsigned int *)t191);
    t202 = (t200 | t201);
    *((unsigned int *)t199) = t202;
    t203 = (t159 + 4);
    t204 = (t191 + 4);
    t205 = (t199 + 4);
    t206 = *((unsigned int *)t203);
    t207 = *((unsigned int *)t204);
    t208 = (t206 | t207);
    *((unsigned int *)t205) = t208;
    t209 = *((unsigned int *)t205);
    t210 = (t209 != 0);
    if (t210 == 1)
        goto LAB69;

LAB70:
LAB71:    goto LAB58;

LAB59:    *((unsigned int *)t172) = 1;
    goto LAB62;

LAB64:    t185 = *((unsigned int *)t172);
    t186 = *((unsigned int *)t182);
    *((unsigned int *)t172) = (t185 | t186);
    t187 = *((unsigned int *)t181);
    t188 = *((unsigned int *)t182);
    *((unsigned int *)t181) = (t187 | t188);
    goto LAB63;

LAB65:    *((unsigned int *)t191) = 1;
    goto LAB68;

LAB67:    t198 = (t191 + 4);
    *((unsigned int *)t191) = 1;
    *((unsigned int *)t198) = 1;
    goto LAB68;

LAB69:    t211 = *((unsigned int *)t199);
    t212 = *((unsigned int *)t205);
    *((unsigned int *)t199) = (t211 | t212);
    t213 = (t159 + 4);
    t214 = (t191 + 4);
    t215 = *((unsigned int *)t213);
    t216 = (~(t215));
    t217 = *((unsigned int *)t159);
    t218 = (t217 & t216);
    t219 = *((unsigned int *)t214);
    t220 = (~(t219));
    t221 = *((unsigned int *)t191);
    t222 = (t221 & t220);
    t223 = (~(t218));
    t224 = (~(t222));
    t225 = *((unsigned int *)t205);
    *((unsigned int *)t205) = (t225 & t223);
    t226 = *((unsigned int *)t205);
    *((unsigned int *)t205) = (t226 & t224);
    goto LAB71;

LAB72:    *((unsigned int *)t227) = 1;
    goto LAB75;

LAB74:    t234 = (t227 + 4);
    *((unsigned int *)t227) = 1;
    *((unsigned int *)t234) = 1;
    goto LAB75;

LAB76:    t240 = (t0 + 1848U);
    t241 = *((char **)t240);
    t240 = (t0 + 2168U);
    t242 = *((char **)t240);
    memset(t243, 0, 8);
    t240 = (t241 + 4);
    t244 = (t242 + 4);
    t245 = *((unsigned int *)t241);
    t246 = *((unsigned int *)t242);
    t247 = (t245 ^ t246);
    t248 = *((unsigned int *)t240);
    t249 = *((unsigned int *)t244);
    t250 = (t248 ^ t249);
    t251 = (t247 | t250);
    t252 = *((unsigned int *)t240);
    t253 = *((unsigned int *)t244);
    t254 = (t252 | t253);
    t255 = (~(t254));
    t256 = (t251 & t255);
    if (t256 != 0)
        goto LAB80;

LAB79:    if (t254 != 0)
        goto LAB81;

LAB82:    memset(t258, 0, 8);
    t259 = (t243 + 4);
    t260 = *((unsigned int *)t259);
    t261 = (~(t260));
    t262 = *((unsigned int *)t243);
    t263 = (t262 & t261);
    t264 = (t263 & 1U);
    if (t264 != 0)
        goto LAB83;

LAB84:    if (*((unsigned int *)t259) != 0)
        goto LAB85;

LAB86:    t267 = *((unsigned int *)t227);
    t268 = *((unsigned int *)t258);
    t269 = (t267 | t268);
    *((unsigned int *)t266) = t269;
    t270 = (t227 + 4);
    t271 = (t258 + 4);
    t272 = (t266 + 4);
    t273 = *((unsigned int *)t270);
    t274 = *((unsigned int *)t271);
    t275 = (t273 | t274);
    *((unsigned int *)t272) = t275;
    t276 = *((unsigned int *)t272);
    t277 = (t276 != 0);
    if (t277 == 1)
        goto LAB87;

LAB88:
LAB89:    goto LAB78;

LAB80:    *((unsigned int *)t243) = 1;
    goto LAB82;

LAB81:    t257 = (t243 + 4);
    *((unsigned int *)t243) = 1;
    *((unsigned int *)t257) = 1;
    goto LAB82;

LAB83:    *((unsigned int *)t258) = 1;
    goto LAB86;

LAB85:    t265 = (t258 + 4);
    *((unsigned int *)t258) = 1;
    *((unsigned int *)t265) = 1;
    goto LAB86;

LAB87:    t278 = *((unsigned int *)t266);
    t279 = *((unsigned int *)t272);
    *((unsigned int *)t266) = (t278 | t279);
    t280 = (t227 + 4);
    t281 = (t258 + 4);
    t282 = *((unsigned int *)t280);
    t283 = (~(t282));
    t284 = *((unsigned int *)t227);
    t285 = (t284 & t283);
    t286 = *((unsigned int *)t281);
    t287 = (~(t286));
    t288 = *((unsigned int *)t258);
    t289 = (t288 & t287);
    t290 = (~(t285));
    t291 = (~(t289));
    t292 = *((unsigned int *)t272);
    *((unsigned int *)t272) = (t292 & t290);
    t293 = *((unsigned int *)t272);
    *((unsigned int *)t272) = (t293 & t291);
    goto LAB89;

LAB90:    *((unsigned int *)t294) = 1;
    goto LAB93;

LAB92:    t301 = (t294 + 4);
    *((unsigned int *)t294) = 1;
    *((unsigned int *)t301) = 1;
    goto LAB93;

LAB94:    t307 = (t0 + 2008U);
    t308 = *((char **)t307);
    t307 = (t0 + 2328U);
    t309 = *((char **)t307);
    memset(t310, 0, 8);
    t307 = (t308 + 4);
    t311 = (t309 + 4);
    t312 = *((unsigned int *)t308);
    t313 = *((unsigned int *)t309);
    t314 = (t312 ^ t313);
    t315 = *((unsigned int *)t307);
    t316 = *((unsigned int *)t311);
    t317 = (t315 ^ t316);
    t318 = (t314 | t317);
    t319 = *((unsigned int *)t307);
    t320 = *((unsigned int *)t311);
    t321 = (t319 | t320);
    t322 = (~(t321));
    t323 = (t318 & t322);
    if (t323 != 0)
        goto LAB98;

LAB97:    if (t321 != 0)
        goto LAB99;

LAB100:    memset(t325, 0, 8);
    t326 = (t310 + 4);
    t327 = *((unsigned int *)t326);
    t328 = (~(t327));
    t329 = *((unsigned int *)t310);
    t330 = (t329 & t328);
    t331 = (t330 & 1U);
    if (t331 != 0)
        goto LAB101;

LAB102:    if (*((unsigned int *)t326) != 0)
        goto LAB103;

LAB104:    t334 = *((unsigned int *)t294);
    t335 = *((unsigned int *)t325);
    t336 = (t334 | t335);
    *((unsigned int *)t333) = t336;
    t337 = (t294 + 4);
    t338 = (t325 + 4);
    t339 = (t333 + 4);
    t340 = *((unsigned int *)t337);
    t341 = *((unsigned int *)t338);
    t342 = (t340 | t341);
    *((unsigned int *)t339) = t342;
    t343 = *((unsigned int *)t339);
    t344 = (t343 != 0);
    if (t344 == 1)
        goto LAB105;

LAB106:
LAB107:    goto LAB96;

LAB98:    *((unsigned int *)t310) = 1;
    goto LAB100;

LAB99:    t324 = (t310 + 4);
    *((unsigned int *)t310) = 1;
    *((unsigned int *)t324) = 1;
    goto LAB100;

LAB101:    *((unsigned int *)t325) = 1;
    goto LAB104;

LAB103:    t332 = (t325 + 4);
    *((unsigned int *)t325) = 1;
    *((unsigned int *)t332) = 1;
    goto LAB104;

LAB105:    t345 = *((unsigned int *)t333);
    t346 = *((unsigned int *)t339);
    *((unsigned int *)t333) = (t345 | t346);
    t347 = (t294 + 4);
    t348 = (t325 + 4);
    t349 = *((unsigned int *)t347);
    t350 = (~(t349));
    t351 = *((unsigned int *)t294);
    t352 = (t351 & t350);
    t353 = *((unsigned int *)t348);
    t354 = (~(t353));
    t355 = *((unsigned int *)t325);
    t356 = (t355 & t354);
    t357 = (~(t352));
    t358 = (~(t356));
    t359 = *((unsigned int *)t339);
    *((unsigned int *)t339) = (t359 & t357);
    t360 = *((unsigned int *)t339);
    *((unsigned int *)t339) = (t360 & t358);
    goto LAB107;

LAB108:    xsi_set_current_line(30, ng0);

LAB111:    xsi_set_current_line(31, ng0);
    t367 = ((char*)((ng1)));
    t368 = (t0 + 2728);
    xsi_vlogvar_wait_assign_value(t368, t367, 0, 0, 1, 0LL);
    xsi_set_current_line(32, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2888);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 11, 0LL);
    goto LAB110;

LAB114:    t14 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t14) = 1;
    goto LAB115;

LAB116:    *((unsigned int *)t23) = 1;
    goto LAB119;

LAB118:    t30 = (t23 + 4);
    *((unsigned int *)t23) = 1;
    *((unsigned int *)t30) = 1;
    goto LAB119;

LAB120:    t37 = (t0 + 2888);
    t38 = (t37 + 56U);
    t44 = *((char **)t38);
    t45 = ((char*)((ng3)));
    memset(t36, 0, 8);
    t46 = (t44 + 4);
    t56 = (t45 + 4);
    t35 = *((unsigned int *)t44);
    t39 = *((unsigned int *)t45);
    t40 = (t35 ^ t39);
    t41 = *((unsigned int *)t46);
    t42 = *((unsigned int *)t56);
    t43 = (t41 ^ t42);
    t47 = (t40 | t43);
    t48 = *((unsigned int *)t46);
    t49 = *((unsigned int *)t56);
    t50 = (t48 | t49);
    t51 = (~(t50));
    t52 = (t47 & t51);
    if (t52 != 0)
        goto LAB126;

LAB123:    if (t50 != 0)
        goto LAB125;

LAB124:    *((unsigned int *)t36) = 1;

LAB126:    memset(t55, 0, 8);
    t67 = (t36 + 4);
    t53 = *((unsigned int *)t67);
    t54 = (~(t53));
    t57 = *((unsigned int *)t36);
    t58 = (t57 & t54);
    t59 = (t58 & 1U);
    if (t59 != 0)
        goto LAB127;

LAB128:    if (*((unsigned int *)t67) != 0)
        goto LAB129;

LAB130:    t60 = *((unsigned int *)t23);
    t61 = *((unsigned int *)t55);
    t64 = (t60 | t61);
    *((unsigned int *)t63) = t64;
    t69 = (t23 + 4);
    t77 = (t55 + 4);
    t78 = (t63 + 4);
    t65 = *((unsigned int *)t69);
    t66 = *((unsigned int *)t77);
    t70 = (t65 | t66);
    *((unsigned int *)t78) = t70;
    t71 = *((unsigned int *)t78);
    t72 = (t71 != 0);
    if (t72 == 1)
        goto LAB131;

LAB132:
LAB133:    goto LAB122;

LAB125:    t62 = (t36 + 4);
    *((unsigned int *)t36) = 1;
    *((unsigned int *)t62) = 1;
    goto LAB126;

LAB127:    *((unsigned int *)t55) = 1;
    goto LAB130;

LAB129:    t68 = (t55 + 4);
    *((unsigned int *)t55) = 1;
    *((unsigned int *)t68) = 1;
    goto LAB130;

LAB131:    t73 = *((unsigned int *)t63);
    t74 = *((unsigned int *)t78);
    *((unsigned int *)t63) = (t73 | t74);
    t92 = (t23 + 4);
    t98 = (t55 + 4);
    t75 = *((unsigned int *)t92);
    t76 = (~(t75));
    t79 = *((unsigned int *)t23);
    t82 = (t79 & t76);
    t80 = *((unsigned int *)t98);
    t81 = (~(t80));
    t83 = *((unsigned int *)t55);
    t86 = (t83 & t81);
    t84 = (~(t82));
    t85 = (~(t86));
    t87 = *((unsigned int *)t78);
    *((unsigned int *)t78) = (t87 & t84);
    t88 = *((unsigned int *)t78);
    *((unsigned int *)t78) = (t88 & t85);
    goto LAB133;

LAB134:    *((unsigned int *)t91) = 1;
    goto LAB137;

LAB136:    t105 = (t91 + 4);
    *((unsigned int *)t91) = 1;
    *((unsigned int *)t105) = 1;
    goto LAB137;

LAB138:    t112 = (t0 + 2888);
    t113 = (t112 + 56U);
    t114 = *((char **)t113);
    t124 = ((char*)((ng4)));
    memset(t104, 0, 8);
    t130 = (t114 + 4);
    t135 = (t124 + 4);
    t102 = *((unsigned int *)t114);
    t103 = *((unsigned int *)t124);
    t107 = (t102 ^ t103);
    t108 = *((unsigned int *)t130);
    t109 = *((unsigned int *)t135);
    t110 = (t108 ^ t109);
    t111 = (t107 | t110);
    t115 = *((unsigned int *)t130);
    t116 = *((unsigned int *)t135);
    t117 = (t115 | t116);
    t118 = (~(t117));
    t119 = (t111 & t118);
    if (t119 != 0)
        goto LAB144;

LAB141:    if (t117 != 0)
        goto LAB143;

LAB142:    *((unsigned int *)t104) = 1;

LAB144:    memset(t123, 0, 8);
    t137 = (t104 + 4);
    t120 = *((unsigned int *)t137);
    t121 = (~(t120));
    t122 = *((unsigned int *)t104);
    t125 = (t122 & t121);
    t126 = (t125 & 1U);
    if (t126 != 0)
        goto LAB145;

LAB146:    if (*((unsigned int *)t137) != 0)
        goto LAB147;

LAB148:    t127 = *((unsigned int *)t91);
    t128 = *((unsigned int *)t123);
    t129 = (t127 | t128);
    *((unsigned int *)t131) = t129;
    t146 = (t91 + 4);
    t160 = (t123 + 4);
    t166 = (t131 + 4);
    t132 = *((unsigned int *)t146);
    t133 = *((unsigned int *)t160);
    t134 = (t132 | t133);
    *((unsigned int *)t166) = t134;
    t138 = *((unsigned int *)t166);
    t139 = (t138 != 0);
    if (t139 == 1)
        goto LAB149;

LAB150:
LAB151:    goto LAB140;

LAB143:    t136 = (t104 + 4);
    *((unsigned int *)t104) = 1;
    *((unsigned int *)t136) = 1;
    goto LAB144;

LAB145:    *((unsigned int *)t123) = 1;
    goto LAB148;

LAB147:    t145 = (t123 + 4);
    *((unsigned int *)t123) = 1;
    *((unsigned int *)t145) = 1;
    goto LAB148;

LAB149:    t140 = *((unsigned int *)t131);
    t141 = *((unsigned int *)t166);
    *((unsigned int *)t131) = (t140 | t141);
    t167 = (t91 + 4);
    t173 = (t123 + 4);
    t142 = *((unsigned int *)t167);
    t143 = (~(t142));
    t144 = *((unsigned int *)t91);
    t150 = (t144 & t143);
    t147 = *((unsigned int *)t173);
    t148 = (~(t147));
    t149 = *((unsigned int *)t123);
    t154 = (t149 & t148);
    t151 = (~(t150));
    t152 = (~(t154));
    t153 = *((unsigned int *)t166);
    *((unsigned int *)t166) = (t153 & t151);
    t155 = *((unsigned int *)t166);
    *((unsigned int *)t166) = (t155 & t152);
    goto LAB151;

LAB152:    *((unsigned int *)t159) = 1;
    goto LAB155;

LAB154:    t180 = (t159 + 4);
    *((unsigned int *)t159) = 1;
    *((unsigned int *)t180) = 1;
    goto LAB155;

LAB156:    t182 = (t0 + 2888);
    t192 = (t182 + 56U);
    t198 = *((char **)t192);
    t203 = ((char*)((ng5)));
    memset(t172, 0, 8);
    t204 = (t198 + 4);
    t205 = (t203 + 4);
    t169 = *((unsigned int *)t198);
    t170 = *((unsigned int *)t203);
    t171 = (t169 ^ t170);
    t175 = *((unsigned int *)t204);
    t176 = *((unsigned int *)t205);
    t177 = (t175 ^ t176);
    t178 = (t171 | t177);
    t179 = *((unsigned int *)t204);
    t183 = *((unsigned int *)t205);
    t184 = (t179 | t183);
    t185 = (~(t184));
    t186 = (t178 & t185);
    if (t186 != 0)
        goto LAB162;

LAB159:    if (t184 != 0)
        goto LAB161;

LAB160:    *((unsigned int *)t172) = 1;

LAB162:    memset(t191, 0, 8);
    t214 = (t172 + 4);
    t187 = *((unsigned int *)t214);
    t188 = (~(t187));
    t189 = *((unsigned int *)t172);
    t190 = (t189 & t188);
    t193 = (t190 & 1U);
    if (t193 != 0)
        goto LAB163;

LAB164:    if (*((unsigned int *)t214) != 0)
        goto LAB165;

LAB166:    t194 = *((unsigned int *)t159);
    t195 = *((unsigned int *)t191);
    t196 = (t194 | t195);
    *((unsigned int *)t199) = t196;
    t234 = (t159 + 4);
    t235 = (t191 + 4);
    t240 = (t199 + 4);
    t197 = *((unsigned int *)t234);
    t200 = *((unsigned int *)t235);
    t201 = (t197 | t200);
    *((unsigned int *)t240) = t201;
    t202 = *((unsigned int *)t240);
    t206 = (t202 != 0);
    if (t206 == 1)
        goto LAB167;

LAB168:
LAB169:    goto LAB158;

LAB161:    t213 = (t172 + 4);
    *((unsigned int *)t172) = 1;
    *((unsigned int *)t213) = 1;
    goto LAB162;

LAB163:    *((unsigned int *)t191) = 1;
    goto LAB166;

LAB165:    t228 = (t191 + 4);
    *((unsigned int *)t191) = 1;
    *((unsigned int *)t228) = 1;
    goto LAB166;

LAB167:    t207 = *((unsigned int *)t199);
    t208 = *((unsigned int *)t240);
    *((unsigned int *)t199) = (t207 | t208);
    t241 = (t159 + 4);
    t242 = (t191 + 4);
    t209 = *((unsigned int *)t241);
    t210 = (~(t209));
    t211 = *((unsigned int *)t159);
    t218 = (t211 & t210);
    t212 = *((unsigned int *)t242);
    t215 = (~(t212));
    t216 = *((unsigned int *)t191);
    t222 = (t216 & t215);
    t217 = (~(t218));
    t219 = (~(t222));
    t220 = *((unsigned int *)t240);
    *((unsigned int *)t240) = (t220 & t217);
    t221 = *((unsigned int *)t240);
    *((unsigned int *)t240) = (t221 & t219);
    goto LAB169;

LAB170:    *((unsigned int *)t227) = 1;
    goto LAB173;

LAB172:    t257 = (t227 + 4);
    *((unsigned int *)t227) = 1;
    *((unsigned int *)t257) = 1;
    goto LAB173;

LAB174:    t265 = (t0 + 2888);
    t270 = (t265 + 56U);
    t271 = *((char **)t270);
    t272 = ((char*)((ng6)));
    memset(t243, 0, 8);
    t280 = (t271 + 4);
    t281 = (t272 + 4);
    t236 = *((unsigned int *)t271);
    t237 = *((unsigned int *)t272);
    t238 = (t236 ^ t237);
    t239 = *((unsigned int *)t280);
    t245 = *((unsigned int *)t281);
    t246 = (t239 ^ t245);
    t247 = (t238 | t246);
    t248 = *((unsigned int *)t280);
    t249 = *((unsigned int *)t281);
    t250 = (t248 | t249);
    t251 = (~(t250));
    t252 = (t247 & t251);
    if (t252 != 0)
        goto LAB180;

LAB177:    if (t250 != 0)
        goto LAB179;

LAB178:    *((unsigned int *)t243) = 1;

LAB180:    memset(t258, 0, 8);
    t301 = (t243 + 4);
    t253 = *((unsigned int *)t301);
    t254 = (~(t253));
    t255 = *((unsigned int *)t243);
    t256 = (t255 & t254);
    t260 = (t256 & 1U);
    if (t260 != 0)
        goto LAB181;

LAB182:    if (*((unsigned int *)t301) != 0)
        goto LAB183;

LAB184:    t261 = *((unsigned int *)t227);
    t262 = *((unsigned int *)t258);
    t263 = (t261 | t262);
    *((unsigned int *)t266) = t263;
    t307 = (t227 + 4);
    t308 = (t258 + 4);
    t309 = (t266 + 4);
    t264 = *((unsigned int *)t307);
    t267 = *((unsigned int *)t308);
    t268 = (t264 | t267);
    *((unsigned int *)t309) = t268;
    t269 = *((unsigned int *)t309);
    t273 = (t269 != 0);
    if (t273 == 1)
        goto LAB185;

LAB186:
LAB187:    goto LAB176;

LAB179:    t295 = (t243 + 4);
    *((unsigned int *)t243) = 1;
    *((unsigned int *)t295) = 1;
    goto LAB180;

LAB181:    *((unsigned int *)t258) = 1;
    goto LAB184;

LAB183:    t302 = (t258 + 4);
    *((unsigned int *)t258) = 1;
    *((unsigned int *)t302) = 1;
    goto LAB184;

LAB185:    t274 = *((unsigned int *)t266);
    t275 = *((unsigned int *)t309);
    *((unsigned int *)t266) = (t274 | t275);
    t311 = (t227 + 4);
    t324 = (t258 + 4);
    t276 = *((unsigned int *)t311);
    t277 = (~(t276));
    t278 = *((unsigned int *)t227);
    t285 = (t278 & t277);
    t279 = *((unsigned int *)t324);
    t282 = (~(t279));
    t283 = *((unsigned int *)t258);
    t289 = (t283 & t282);
    t284 = (~(t285));
    t286 = (~(t289));
    t287 = *((unsigned int *)t309);
    *((unsigned int *)t309) = (t287 & t284);
    t288 = *((unsigned int *)t309);
    *((unsigned int *)t309) = (t288 & t286);
    goto LAB187;

LAB188:    *((unsigned int *)t294) = 1;
    goto LAB191;

LAB190:    t332 = (t294 + 4);
    *((unsigned int *)t294) = 1;
    *((unsigned int *)t332) = 1;
    goto LAB191;

LAB192:    t338 = (t0 + 2888);
    t339 = (t338 + 56U);
    t347 = *((char **)t339);
    t348 = ((char*)((ng7)));
    memset(t310, 0, 8);
    t361 = (t347 + 4);
    t367 = (t348 + 4);
    t303 = *((unsigned int *)t347);
    t304 = *((unsigned int *)t348);
    t305 = (t303 ^ t304);
    t306 = *((unsigned int *)t361);
    t312 = *((unsigned int *)t367);
    t313 = (t306 ^ t312);
    t314 = (t305 | t313);
    t315 = *((unsigned int *)t361);
    t316 = *((unsigned int *)t367);
    t317 = (t315 | t316);
    t318 = (~(t317));
    t319 = (t314 & t318);
    if (t319 != 0)
        goto LAB198;

LAB195:    if (t317 != 0)
        goto LAB197;

LAB196:    *((unsigned int *)t310) = 1;

LAB198:    memset(t325, 0, 8);
    t369 = (t310 + 4);
    t320 = *((unsigned int *)t369);
    t321 = (~(t320));
    t322 = *((unsigned int *)t310);
    t323 = (t322 & t321);
    t327 = (t323 & 1U);
    if (t327 != 0)
        goto LAB199;

LAB200:    if (*((unsigned int *)t369) != 0)
        goto LAB201;

LAB202:    t328 = *((unsigned int *)t294);
    t329 = *((unsigned int *)t325);
    t330 = (t328 | t329);
    *((unsigned int *)t333) = t330;
    t371 = (t294 + 4);
    t372 = (t325 + 4);
    t373 = (t333 + 4);
    t331 = *((unsigned int *)t371);
    t334 = *((unsigned int *)t372);
    t335 = (t331 | t334);
    *((unsigned int *)t373) = t335;
    t336 = *((unsigned int *)t373);
    t340 = (t336 != 0);
    if (t340 == 1)
        goto LAB203;

LAB204:
LAB205:    goto LAB194;

LAB197:    t368 = (t310 + 4);
    *((unsigned int *)t310) = 1;
    *((unsigned int *)t368) = 1;
    goto LAB198;

LAB199:    *((unsigned int *)t325) = 1;
    goto LAB202;

LAB201:    t370 = (t325 + 4);
    *((unsigned int *)t325) = 1;
    *((unsigned int *)t370) = 1;
    goto LAB202;

LAB203:    t341 = *((unsigned int *)t333);
    t342 = *((unsigned int *)t373);
    *((unsigned int *)t333) = (t341 | t342);
    t374 = (t294 + 4);
    t375 = (t325 + 4);
    t343 = *((unsigned int *)t374);
    t344 = (~(t343));
    t345 = *((unsigned int *)t294);
    t352 = (t345 & t344);
    t346 = *((unsigned int *)t375);
    t349 = (~(t346));
    t350 = *((unsigned int *)t325);
    t356 = (t350 & t349);
    t351 = (~(t352));
    t353 = (~(t356));
    t354 = *((unsigned int *)t373);
    *((unsigned int *)t373) = (t354 & t351);
    t355 = *((unsigned int *)t373);
    *((unsigned int *)t373) = (t355 & t353);
    goto LAB205;

LAB206:    xsi_set_current_line(35, ng0);

LAB209:    xsi_set_current_line(36, ng0);
    t377 = (t0 + 2888);
    t378 = (t377 + 56U);
    t379 = *((char **)t378);
    t380 = ((char*)((ng8)));
    memset(t381, 0, 8);
    xsi_vlog_unsigned_add(t381, 11, t379, 11, t380, 11);
    t382 = (t0 + 2888);
    xsi_vlogvar_wait_assign_value(t382, t381, 0, 0, 11, 0LL);
    xsi_set_current_line(37, ng0);
    t2 = (t0 + 2728);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    memset(t4, 0, 8);
    t6 = (t5 + 4);
    t7 = *((unsigned int *)t6);
    t8 = (~(t7));
    t9 = *((unsigned int *)t5);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB213;

LAB211:    if (*((unsigned int *)t6) == 0)
        goto LAB210;

LAB212:    t12 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t12) = 1;

LAB213:    t13 = (t4 + 4);
    t14 = (t5 + 4);
    t15 = *((unsigned int *)t5);
    t16 = (~(t15));
    *((unsigned int *)t4) = t16;
    *((unsigned int *)t13) = 0;
    if (*((unsigned int *)t14) != 0)
        goto LAB215;

LAB214:    t21 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t21 & 1U);
    t22 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t22 & 1U);
    t24 = (t0 + 2728);
    xsi_vlogvar_wait_assign_value(t24, t4, 0, 0, 1, 0LL);
    goto LAB208;

LAB210:    *((unsigned int *)t4) = 1;
    goto LAB213;

LAB215:    t17 = *((unsigned int *)t4);
    t18 = *((unsigned int *)t14);
    *((unsigned int *)t4) = (t17 | t18);
    t19 = *((unsigned int *)t13);
    t20 = *((unsigned int *)t14);
    *((unsigned int *)t13) = (t19 | t20);
    goto LAB214;

LAB218:    t14 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t14) = 1;
    goto LAB219;

LAB220:    xsi_set_current_line(39, ng0);
    t30 = ((char*)((ng1)));
    t31 = (t0 + 2888);
    xsi_vlogvar_wait_assign_value(t31, t30, 0, 0, 11, 0LL);
    goto LAB222;

}


extern void work_m_00000000000392773824_2052931248_init()
{
	static char *pe[] = {(void *)Always_27_0};
	xsi_register_didat("work_m_00000000000392773824_2052931248", "isim/testclock_isim_beh.exe.sim/work/m_00000000000392773824_2052931248.didat");
	xsi_register_executes(pe);
}
