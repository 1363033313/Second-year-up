/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "H:/ISEFILES/zhong/shuzizhong/zheng.v";
static int ng1[] = {0, 0};
static unsigned int ng2[] = {35U, 0U};
static int ng3[] = {46, 0};
static int ng4[] = {22, 0};
static unsigned int ng5[] = {34U, 0U};
static int ng6[] = {44, 0};
static int ng7[] = {20, 0};
static unsigned int ng8[] = {33U, 0U};
static int ng9[] = {42, 0};
static int ng10[] = {18, 0};
static unsigned int ng11[] = {32U, 0U};
static int ng12[] = {40, 0};
static int ng13[] = {16, 0};
static unsigned int ng14[] = {25U, 0U};
static int ng15[] = {38, 0};
static int ng16[] = {14, 0};
static unsigned int ng17[] = {24U, 0U};
static int ng18[] = {36, 0};
static int ng19[] = {12, 0};
static unsigned int ng20[] = {23U, 0U};
static int ng21[] = {34, 0};
static int ng22[] = {10, 0};
static unsigned int ng23[] = {22U, 0U};
static int ng24[] = {32, 0};
static int ng25[] = {8, 0};
static unsigned int ng26[] = {21U, 0U};
static int ng27[] = {30, 0};
static int ng28[] = {6, 0};
static unsigned int ng29[] = {20U, 0U};
static int ng30[] = {28, 0};
static int ng31[] = {4, 0};
static unsigned int ng32[] = {19U, 0U};
static int ng33[] = {26, 0};
static int ng34[] = {2, 0};
static unsigned int ng35[] = {18U, 0U};
static int ng36[] = {24, 0};
static unsigned int ng37[] = {17U, 0U};
static unsigned int ng38[] = {16U, 0U};
static unsigned int ng39[] = {9U, 0U};
static unsigned int ng40[] = {8U, 0U};
static unsigned int ng41[] = {7U, 0U};
static unsigned int ng42[] = {6U, 0U};
static unsigned int ng43[] = {5U, 0U};
static unsigned int ng44[] = {4U, 0U};
static unsigned int ng45[] = {3U, 0U};
static unsigned int ng46[] = {2U, 0U};
static unsigned int ng47[] = {1U, 0U};
static unsigned int ng48[] = {0U, 0U};
static int ng49[] = {48, 0};



static void Always_27_0(char *t0)
{
    char t4[8];
    char t23[8];
    char t36[8];
    char t55[8];
    char t63[8];
    char t101[8];
    char t102[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    char *t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    char *t30;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    char *t37;
    char *t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    char *t44;
    char *t45;
    char *t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    char *t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    char *t62;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    char *t67;
    char *t68;
    char *t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    char *t77;
    char *t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    int t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    int t86;
    unsigned int t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    char *t91;
    unsigned int t92;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    char *t97;
    char *t98;
    unsigned int t99;
    int t100;
    unsigned int t103;
    unsigned int t104;
    unsigned int t105;
    unsigned int t106;
    unsigned int t107;
    char *t108;
    char *t109;
    unsigned int t110;
    unsigned int t111;
    unsigned int t112;
    char *t113;
    unsigned int t114;
    unsigned int t115;
    unsigned int t116;
    unsigned int t117;
    char *t118;
    char *t119;

LAB0:    t1 = (t0 + 3488U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(27, ng0);
    t2 = (t0 + 3808);
    *((int *)t2) = 1;
    t3 = (t0 + 3520);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(28, ng0);

LAB5:    xsi_set_current_line(29, ng0);
    t5 = (t0 + 1208U);
    t6 = *((char **)t5);
    memset(t4, 0, 8);
    t5 = (t6 + 4);
    t7 = *((unsigned int *)t5);
    t8 = (~(t7));
    t9 = *((unsigned int *)t6);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB9;

LAB7:    if (*((unsigned int *)t5) == 0)
        goto LAB6;

LAB8:    t12 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t12) = 1;

LAB9:    t13 = (t4 + 4);
    t14 = (t6 + 4);
    t15 = *((unsigned int *)t6);
    t16 = (~(t15));
    *((unsigned int *)t4) = t16;
    *((unsigned int *)t13) = 0;
    if (*((unsigned int *)t14) != 0)
        goto LAB11;

LAB10:    t21 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t21 & 1U);
    t22 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t22 & 1U);
    memset(t23, 0, 8);
    t24 = (t4 + 4);
    t25 = *((unsigned int *)t24);
    t26 = (~(t25));
    t27 = *((unsigned int *)t4);
    t28 = (t27 & t26);
    t29 = (t28 & 1U);
    if (t29 != 0)
        goto LAB12;

LAB13:    if (*((unsigned int *)t24) != 0)
        goto LAB14;

LAB15:    t31 = (t23 + 4);
    t32 = *((unsigned int *)t23);
    t33 = (!(t32));
    t34 = *((unsigned int *)t31);
    t35 = (t33 || t34);
    if (t35 > 0)
        goto LAB16;

LAB17:    memcpy(t63, t23, 8);

LAB18:    t91 = (t63 + 4);
    t92 = *((unsigned int *)t91);
    t93 = (~(t92));
    t94 = *((unsigned int *)t63);
    t95 = (t94 & t93);
    t96 = (t95 != 0);
    if (t96 > 0)
        goto LAB32;

LAB33:    xsi_set_current_line(35, ng0);
    t2 = (t0 + 1688U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng1)));
    memset(t4, 0, 8);
    t5 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t5);
    t11 = *((unsigned int *)t6);
    t15 = (t10 ^ t11);
    t16 = (t9 | t15);
    t17 = *((unsigned int *)t5);
    t18 = *((unsigned int *)t6);
    t19 = (t17 | t18);
    t20 = (~(t19));
    t21 = (t16 & t20);
    if (t21 != 0)
        goto LAB39;

LAB36:    if (t19 != 0)
        goto LAB38;

LAB37:    *((unsigned int *)t4) = 1;

LAB39:    memset(t23, 0, 8);
    t13 = (t4 + 4);
    t22 = *((unsigned int *)t13);
    t25 = (~(t22));
    t26 = *((unsigned int *)t4);
    t27 = (t26 & t25);
    t28 = (t27 & 1U);
    if (t28 != 0)
        goto LAB40;

LAB41:    if (*((unsigned int *)t13) != 0)
        goto LAB42;

LAB43:    t24 = (t23 + 4);
    t29 = *((unsigned int *)t23);
    t32 = *((unsigned int *)t24);
    t33 = (t29 || t32);
    if (t33 > 0)
        goto LAB44;

LAB45:    memcpy(t63, t23, 8);

LAB46:    t77 = (t63 + 4);
    t93 = *((unsigned int *)t77);
    t94 = (~(t93));
    t95 = *((unsigned int *)t63);
    t96 = (t95 & t94);
    t99 = (t96 != 0);
    if (t99 > 0)
        goto LAB58;

LAB59:    xsi_set_current_line(66, ng0);
    t2 = (t0 + 2568);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = ((char*)((ng1)));
    memset(t4, 0, 8);
    xsi_vlog_signed_greater(t4, 32, t5, 32, t6, 32);
    t12 = (t4 + 4);
    t7 = *((unsigned int *)t12);
    t8 = (~(t7));
    t9 = *((unsigned int *)t4);
    t10 = (t9 & t8);
    t11 = (t10 != 0);
    if (t11 > 0)
        goto LAB270;

LAB271:    xsi_set_current_line(72, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2408);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);

LAB272:
LAB60:
LAB34:    goto LAB2;

LAB6:    *((unsigned int *)t4) = 1;
    goto LAB9;

LAB11:    t17 = *((unsigned int *)t4);
    t18 = *((unsigned int *)t14);
    *((unsigned int *)t4) = (t17 | t18);
    t19 = *((unsigned int *)t13);
    t20 = *((unsigned int *)t14);
    *((unsigned int *)t13) = (t19 | t20);
    goto LAB10;

LAB12:    *((unsigned int *)t23) = 1;
    goto LAB15;

LAB14:    t30 = (t23 + 4);
    *((unsigned int *)t23) = 1;
    *((unsigned int *)t30) = 1;
    goto LAB15;

LAB16:    t37 = (t0 + 1368U);
    t38 = *((char **)t37);
    memset(t36, 0, 8);
    t37 = (t38 + 4);
    t39 = *((unsigned int *)t37);
    t40 = (~(t39));
    t41 = *((unsigned int *)t38);
    t42 = (t41 & t40);
    t43 = (t42 & 1U);
    if (t43 != 0)
        goto LAB22;

LAB20:    if (*((unsigned int *)t37) == 0)
        goto LAB19;

LAB21:    t44 = (t36 + 4);
    *((unsigned int *)t36) = 1;
    *((unsigned int *)t44) = 1;

LAB22:    t45 = (t36 + 4);
    t46 = (t38 + 4);
    t47 = *((unsigned int *)t38);
    t48 = (~(t47));
    *((unsigned int *)t36) = t48;
    *((unsigned int *)t45) = 0;
    if (*((unsigned int *)t46) != 0)
        goto LAB24;

LAB23:    t53 = *((unsigned int *)t36);
    *((unsigned int *)t36) = (t53 & 1U);
    t54 = *((unsigned int *)t45);
    *((unsigned int *)t45) = (t54 & 1U);
    memset(t55, 0, 8);
    t56 = (t36 + 4);
    t57 = *((unsigned int *)t56);
    t58 = (~(t57));
    t59 = *((unsigned int *)t36);
    t60 = (t59 & t58);
    t61 = (t60 & 1U);
    if (t61 != 0)
        goto LAB25;

LAB26:    if (*((unsigned int *)t56) != 0)
        goto LAB27;

LAB28:    t64 = *((unsigned int *)t23);
    t65 = *((unsigned int *)t55);
    t66 = (t64 | t65);
    *((unsigned int *)t63) = t66;
    t67 = (t23 + 4);
    t68 = (t55 + 4);
    t69 = (t63 + 4);
    t70 = *((unsigned int *)t67);
    t71 = *((unsigned int *)t68);
    t72 = (t70 | t71);
    *((unsigned int *)t69) = t72;
    t73 = *((unsigned int *)t69);
    t74 = (t73 != 0);
    if (t74 == 1)
        goto LAB29;

LAB30:
LAB31:    goto LAB18;

LAB19:    *((unsigned int *)t36) = 1;
    goto LAB22;

LAB24:    t49 = *((unsigned int *)t36);
    t50 = *((unsigned int *)t46);
    *((unsigned int *)t36) = (t49 | t50);
    t51 = *((unsigned int *)t45);
    t52 = *((unsigned int *)t46);
    *((unsigned int *)t45) = (t51 | t52);
    goto LAB23;

LAB25:    *((unsigned int *)t55) = 1;
    goto LAB28;

LAB27:    t62 = (t55 + 4);
    *((unsigned int *)t55) = 1;
    *((unsigned int *)t62) = 1;
    goto LAB28;

LAB29:    t75 = *((unsigned int *)t63);
    t76 = *((unsigned int *)t69);
    *((unsigned int *)t63) = (t75 | t76);
    t77 = (t23 + 4);
    t78 = (t55 + 4);
    t79 = *((unsigned int *)t77);
    t80 = (~(t79));
    t81 = *((unsigned int *)t23);
    t82 = (t81 & t80);
    t83 = *((unsigned int *)t78);
    t84 = (~(t83));
    t85 = *((unsigned int *)t55);
    t86 = (t85 & t84);
    t87 = (~(t82));
    t88 = (~(t86));
    t89 = *((unsigned int *)t69);
    *((unsigned int *)t69) = (t89 & t87);
    t90 = *((unsigned int *)t69);
    *((unsigned int *)t69) = (t90 & t88);
    goto LAB31;

LAB32:    xsi_set_current_line(30, ng0);

LAB35:    xsi_set_current_line(31, ng0);
    t97 = ((char*)((ng1)));
    t98 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t98, t97, 0, 0, 32, 0LL);
    xsi_set_current_line(32, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2408);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    goto LAB34;

LAB38:    t12 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t12) = 1;
    goto LAB39;

LAB40:    *((unsigned int *)t23) = 1;
    goto LAB43;

LAB42:    t14 = (t23 + 4);
    *((unsigned int *)t23) = 1;
    *((unsigned int *)t14) = 1;
    goto LAB43;

LAB44:    t30 = (t0 + 1848U);
    t31 = *((char **)t30);
    t30 = ((char*)((ng1)));
    memset(t36, 0, 8);
    t37 = (t31 + 4);
    t38 = (t30 + 4);
    t34 = *((unsigned int *)t31);
    t35 = *((unsigned int *)t30);
    t39 = (t34 ^ t35);
    t40 = *((unsigned int *)t37);
    t41 = *((unsigned int *)t38);
    t42 = (t40 ^ t41);
    t43 = (t39 | t42);
    t47 = *((unsigned int *)t37);
    t48 = *((unsigned int *)t38);
    t49 = (t47 | t48);
    t50 = (~(t49));
    t51 = (t43 & t50);
    if (t51 != 0)
        goto LAB50;

LAB47:    if (t49 != 0)
        goto LAB49;

LAB48:    *((unsigned int *)t36) = 1;

LAB50:    memset(t55, 0, 8);
    t45 = (t36 + 4);
    t52 = *((unsigned int *)t45);
    t53 = (~(t52));
    t54 = *((unsigned int *)t36);
    t57 = (t54 & t53);
    t58 = (t57 & 1U);
    if (t58 != 0)
        goto LAB51;

LAB52:    if (*((unsigned int *)t45) != 0)
        goto LAB53;

LAB54:    t59 = *((unsigned int *)t23);
    t60 = *((unsigned int *)t55);
    t61 = (t59 & t60);
    *((unsigned int *)t63) = t61;
    t56 = (t23 + 4);
    t62 = (t55 + 4);
    t67 = (t63 + 4);
    t64 = *((unsigned int *)t56);
    t65 = *((unsigned int *)t62);
    t66 = (t64 | t65);
    *((unsigned int *)t67) = t66;
    t70 = *((unsigned int *)t67);
    t71 = (t70 != 0);
    if (t71 == 1)
        goto LAB55;

LAB56:
LAB57:    goto LAB46;

LAB49:    t44 = (t36 + 4);
    *((unsigned int *)t36) = 1;
    *((unsigned int *)t44) = 1;
    goto LAB50;

LAB51:    *((unsigned int *)t55) = 1;
    goto LAB54;

LAB53:    t46 = (t55 + 4);
    *((unsigned int *)t55) = 1;
    *((unsigned int *)t46) = 1;
    goto LAB54;

LAB55:    t72 = *((unsigned int *)t63);
    t73 = *((unsigned int *)t67);
    *((unsigned int *)t63) = (t72 | t73);
    t68 = (t23 + 4);
    t69 = (t55 + 4);
    t74 = *((unsigned int *)t23);
    t75 = (~(t74));
    t76 = *((unsigned int *)t68);
    t79 = (~(t76));
    t80 = *((unsigned int *)t55);
    t81 = (~(t80));
    t83 = *((unsigned int *)t69);
    t84 = (~(t83));
    t82 = (t75 & t79);
    t86 = (t81 & t84);
    t85 = (~(t82));
    t87 = (~(t86));
    t88 = *((unsigned int *)t67);
    *((unsigned int *)t67) = (t88 & t85);
    t89 = *((unsigned int *)t67);
    *((unsigned int *)t67) = (t89 & t87);
    t90 = *((unsigned int *)t63);
    *((unsigned int *)t63) = (t90 & t85);
    t92 = *((unsigned int *)t63);
    *((unsigned int *)t63) = (t92 & t87);
    goto LAB57;

LAB58:    xsi_set_current_line(36, ng0);

LAB61:    xsi_set_current_line(37, ng0);
    t78 = (t0 + 2008U);
    t91 = *((char **)t78);

LAB62:    t78 = ((char*)((ng2)));
    t100 = xsi_vlog_unsigned_case_compare(t91, 8, t78, 8);
    if (t100 == 1)
        goto LAB63;

LAB64:    t2 = ((char*)((ng5)));
    t82 = xsi_vlog_unsigned_case_compare(t91, 8, t2, 8);
    if (t82 == 1)
        goto LAB65;

LAB66:    t2 = ((char*)((ng8)));
    t82 = xsi_vlog_unsigned_case_compare(t91, 8, t2, 8);
    if (t82 == 1)
        goto LAB67;

LAB68:    t2 = ((char*)((ng11)));
    t82 = xsi_vlog_unsigned_case_compare(t91, 8, t2, 8);
    if (t82 == 1)
        goto LAB69;

LAB70:    t2 = ((char*)((ng14)));
    t82 = xsi_vlog_unsigned_case_compare(t91, 8, t2, 8);
    if (t82 == 1)
        goto LAB71;

LAB72:    t2 = ((char*)((ng17)));
    t82 = xsi_vlog_unsigned_case_compare(t91, 8, t2, 8);
    if (t82 == 1)
        goto LAB73;

LAB74:    t2 = ((char*)((ng20)));
    t82 = xsi_vlog_unsigned_case_compare(t91, 8, t2, 8);
    if (t82 == 1)
        goto LAB75;

LAB76:    t2 = ((char*)((ng23)));
    t82 = xsi_vlog_unsigned_case_compare(t91, 8, t2, 8);
    if (t82 == 1)
        goto LAB77;

LAB78:    t2 = ((char*)((ng26)));
    t82 = xsi_vlog_unsigned_case_compare(t91, 8, t2, 8);
    if (t82 == 1)
        goto LAB79;

LAB80:    t2 = ((char*)((ng29)));
    t82 = xsi_vlog_unsigned_case_compare(t91, 8, t2, 8);
    if (t82 == 1)
        goto LAB81;

LAB82:    t2 = ((char*)((ng32)));
    t82 = xsi_vlog_unsigned_case_compare(t91, 8, t2, 8);
    if (t82 == 1)
        goto LAB83;

LAB84:    t2 = ((char*)((ng35)));
    t82 = xsi_vlog_unsigned_case_compare(t91, 8, t2, 8);
    if (t82 == 1)
        goto LAB85;

LAB86:    t2 = ((char*)((ng37)));
    t82 = xsi_vlog_unsigned_case_compare(t91, 8, t2, 8);
    if (t82 == 1)
        goto LAB87;

LAB88:    t2 = ((char*)((ng38)));
    t82 = xsi_vlog_unsigned_case_compare(t91, 8, t2, 8);
    if (t82 == 1)
        goto LAB89;

LAB90:    t2 = ((char*)((ng39)));
    t82 = xsi_vlog_unsigned_case_compare(t91, 8, t2, 8);
    if (t82 == 1)
        goto LAB91;

LAB92:    t2 = ((char*)((ng40)));
    t82 = xsi_vlog_unsigned_case_compare(t91, 8, t2, 8);
    if (t82 == 1)
        goto LAB93;

LAB94:    t2 = ((char*)((ng41)));
    t82 = xsi_vlog_unsigned_case_compare(t91, 8, t2, 8);
    if (t82 == 1)
        goto LAB95;

LAB96:    t2 = ((char*)((ng42)));
    t82 = xsi_vlog_unsigned_case_compare(t91, 8, t2, 8);
    if (t82 == 1)
        goto LAB97;

LAB98:    t2 = ((char*)((ng43)));
    t82 = xsi_vlog_unsigned_case_compare(t91, 8, t2, 8);
    if (t82 == 1)
        goto LAB99;

LAB100:    t2 = ((char*)((ng44)));
    t82 = xsi_vlog_unsigned_case_compare(t91, 8, t2, 8);
    if (t82 == 1)
        goto LAB101;

LAB102:    t2 = ((char*)((ng45)));
    t82 = xsi_vlog_unsigned_case_compare(t91, 8, t2, 8);
    if (t82 == 1)
        goto LAB103;

LAB104:    t2 = ((char*)((ng46)));
    t82 = xsi_vlog_unsigned_case_compare(t91, 8, t2, 8);
    if (t82 == 1)
        goto LAB105;

LAB106:    t2 = ((char*)((ng47)));
    t82 = xsi_vlog_unsigned_case_compare(t91, 8, t2, 8);
    if (t82 == 1)
        goto LAB107;

LAB108:    t2 = ((char*)((ng48)));
    t82 = xsi_vlog_unsigned_case_compare(t91, 8, t2, 8);
    if (t82 == 1)
        goto LAB109;

LAB110:
LAB112:
LAB111:    xsi_set_current_line(62, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 32, 0LL);

LAB113:    goto LAB60;

LAB63:    xsi_set_current_line(38, ng0);
    t97 = (t0 + 1528U);
    t98 = *((char **)t97);
    memset(t102, 0, 8);
    t97 = (t98 + 4);
    t103 = *((unsigned int *)t97);
    t104 = (~(t103));
    t105 = *((unsigned int *)t98);
    t106 = (t105 & t104);
    t107 = (t106 & 1U);
    if (t107 != 0)
        goto LAB114;

LAB115:    if (*((unsigned int *)t97) != 0)
        goto LAB116;

LAB117:    t109 = (t102 + 4);
    t110 = *((unsigned int *)t102);
    t111 = *((unsigned int *)t109);
    t112 = (t110 || t111);
    if (t112 > 0)
        goto LAB118;

LAB119:    t114 = *((unsigned int *)t102);
    t115 = (~(t114));
    t116 = *((unsigned int *)t109);
    t117 = (t115 || t116);
    if (t117 > 0)
        goto LAB120;

LAB121:    if (*((unsigned int *)t109) > 0)
        goto LAB122;

LAB123:    if (*((unsigned int *)t102) > 0)
        goto LAB124;

LAB125:    memcpy(t101, t118, 8);

LAB126:    t119 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t119, t101, 0, 0, 32, 0LL);
    goto LAB113;

LAB65:    xsi_set_current_line(39, ng0);
    t3 = (t0 + 1528U);
    t5 = *((char **)t3);
    memset(t23, 0, 8);
    t3 = (t5 + 4);
    t7 = *((unsigned int *)t3);
    t8 = (~(t7));
    t9 = *((unsigned int *)t5);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB127;

LAB128:    if (*((unsigned int *)t3) != 0)
        goto LAB129;

LAB130:    t12 = (t23 + 4);
    t15 = *((unsigned int *)t23);
    t16 = *((unsigned int *)t12);
    t17 = (t15 || t16);
    if (t17 > 0)
        goto LAB131;

LAB132:    t18 = *((unsigned int *)t23);
    t19 = (~(t18));
    t20 = *((unsigned int *)t12);
    t21 = (t19 || t20);
    if (t21 > 0)
        goto LAB133;

LAB134:    if (*((unsigned int *)t12) > 0)
        goto LAB135;

LAB136:    if (*((unsigned int *)t23) > 0)
        goto LAB137;

LAB138:    memcpy(t4, t14, 8);

LAB139:    t24 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t24, t4, 0, 0, 32, 0LL);
    goto LAB113;

LAB67:    xsi_set_current_line(40, ng0);
    t3 = (t0 + 1528U);
    t5 = *((char **)t3);
    memset(t23, 0, 8);
    t3 = (t5 + 4);
    t7 = *((unsigned int *)t3);
    t8 = (~(t7));
    t9 = *((unsigned int *)t5);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB140;

LAB141:    if (*((unsigned int *)t3) != 0)
        goto LAB142;

LAB143:    t12 = (t23 + 4);
    t15 = *((unsigned int *)t23);
    t16 = *((unsigned int *)t12);
    t17 = (t15 || t16);
    if (t17 > 0)
        goto LAB144;

LAB145:    t18 = *((unsigned int *)t23);
    t19 = (~(t18));
    t20 = *((unsigned int *)t12);
    t21 = (t19 || t20);
    if (t21 > 0)
        goto LAB146;

LAB147:    if (*((unsigned int *)t12) > 0)
        goto LAB148;

LAB149:    if (*((unsigned int *)t23) > 0)
        goto LAB150;

LAB151:    memcpy(t4, t14, 8);

LAB152:    t24 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t24, t4, 0, 0, 32, 0LL);
    goto LAB113;

LAB69:    xsi_set_current_line(41, ng0);
    t3 = (t0 + 1528U);
    t5 = *((char **)t3);
    memset(t23, 0, 8);
    t3 = (t5 + 4);
    t7 = *((unsigned int *)t3);
    t8 = (~(t7));
    t9 = *((unsigned int *)t5);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB153;

LAB154:    if (*((unsigned int *)t3) != 0)
        goto LAB155;

LAB156:    t12 = (t23 + 4);
    t15 = *((unsigned int *)t23);
    t16 = *((unsigned int *)t12);
    t17 = (t15 || t16);
    if (t17 > 0)
        goto LAB157;

LAB158:    t18 = *((unsigned int *)t23);
    t19 = (~(t18));
    t20 = *((unsigned int *)t12);
    t21 = (t19 || t20);
    if (t21 > 0)
        goto LAB159;

LAB160:    if (*((unsigned int *)t12) > 0)
        goto LAB161;

LAB162:    if (*((unsigned int *)t23) > 0)
        goto LAB163;

LAB164:    memcpy(t4, t14, 8);

LAB165:    t24 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t24, t4, 0, 0, 32, 0LL);
    goto LAB113;

LAB71:    xsi_set_current_line(42, ng0);
    t3 = (t0 + 1528U);
    t5 = *((char **)t3);
    memset(t23, 0, 8);
    t3 = (t5 + 4);
    t7 = *((unsigned int *)t3);
    t8 = (~(t7));
    t9 = *((unsigned int *)t5);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB166;

LAB167:    if (*((unsigned int *)t3) != 0)
        goto LAB168;

LAB169:    t12 = (t23 + 4);
    t15 = *((unsigned int *)t23);
    t16 = *((unsigned int *)t12);
    t17 = (t15 || t16);
    if (t17 > 0)
        goto LAB170;

LAB171:    t18 = *((unsigned int *)t23);
    t19 = (~(t18));
    t20 = *((unsigned int *)t12);
    t21 = (t19 || t20);
    if (t21 > 0)
        goto LAB172;

LAB173:    if (*((unsigned int *)t12) > 0)
        goto LAB174;

LAB175:    if (*((unsigned int *)t23) > 0)
        goto LAB176;

LAB177:    memcpy(t4, t14, 8);

LAB178:    t24 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t24, t4, 0, 0, 32, 0LL);
    goto LAB113;

LAB73:    xsi_set_current_line(43, ng0);
    t3 = (t0 + 1528U);
    t5 = *((char **)t3);
    memset(t23, 0, 8);
    t3 = (t5 + 4);
    t7 = *((unsigned int *)t3);
    t8 = (~(t7));
    t9 = *((unsigned int *)t5);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB179;

LAB180:    if (*((unsigned int *)t3) != 0)
        goto LAB181;

LAB182:    t12 = (t23 + 4);
    t15 = *((unsigned int *)t23);
    t16 = *((unsigned int *)t12);
    t17 = (t15 || t16);
    if (t17 > 0)
        goto LAB183;

LAB184:    t18 = *((unsigned int *)t23);
    t19 = (~(t18));
    t20 = *((unsigned int *)t12);
    t21 = (t19 || t20);
    if (t21 > 0)
        goto LAB185;

LAB186:    if (*((unsigned int *)t12) > 0)
        goto LAB187;

LAB188:    if (*((unsigned int *)t23) > 0)
        goto LAB189;

LAB190:    memcpy(t4, t14, 8);

LAB191:    t24 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t24, t4, 0, 0, 32, 0LL);
    goto LAB113;

LAB75:    xsi_set_current_line(44, ng0);
    t3 = (t0 + 1528U);
    t5 = *((char **)t3);
    memset(t23, 0, 8);
    t3 = (t5 + 4);
    t7 = *((unsigned int *)t3);
    t8 = (~(t7));
    t9 = *((unsigned int *)t5);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB192;

LAB193:    if (*((unsigned int *)t3) != 0)
        goto LAB194;

LAB195:    t12 = (t23 + 4);
    t15 = *((unsigned int *)t23);
    t16 = *((unsigned int *)t12);
    t17 = (t15 || t16);
    if (t17 > 0)
        goto LAB196;

LAB197:    t18 = *((unsigned int *)t23);
    t19 = (~(t18));
    t20 = *((unsigned int *)t12);
    t21 = (t19 || t20);
    if (t21 > 0)
        goto LAB198;

LAB199:    if (*((unsigned int *)t12) > 0)
        goto LAB200;

LAB201:    if (*((unsigned int *)t23) > 0)
        goto LAB202;

LAB203:    memcpy(t4, t14, 8);

LAB204:    t24 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t24, t4, 0, 0, 32, 0LL);
    goto LAB113;

LAB77:    xsi_set_current_line(45, ng0);
    t3 = (t0 + 1528U);
    t5 = *((char **)t3);
    memset(t23, 0, 8);
    t3 = (t5 + 4);
    t7 = *((unsigned int *)t3);
    t8 = (~(t7));
    t9 = *((unsigned int *)t5);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB205;

LAB206:    if (*((unsigned int *)t3) != 0)
        goto LAB207;

LAB208:    t12 = (t23 + 4);
    t15 = *((unsigned int *)t23);
    t16 = *((unsigned int *)t12);
    t17 = (t15 || t16);
    if (t17 > 0)
        goto LAB209;

LAB210:    t18 = *((unsigned int *)t23);
    t19 = (~(t18));
    t20 = *((unsigned int *)t12);
    t21 = (t19 || t20);
    if (t21 > 0)
        goto LAB211;

LAB212:    if (*((unsigned int *)t12) > 0)
        goto LAB213;

LAB214:    if (*((unsigned int *)t23) > 0)
        goto LAB215;

LAB216:    memcpy(t4, t14, 8);

LAB217:    t24 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t24, t4, 0, 0, 32, 0LL);
    goto LAB113;

LAB79:    xsi_set_current_line(46, ng0);
    t3 = (t0 + 1528U);
    t5 = *((char **)t3);
    memset(t23, 0, 8);
    t3 = (t5 + 4);
    t7 = *((unsigned int *)t3);
    t8 = (~(t7));
    t9 = *((unsigned int *)t5);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB218;

LAB219:    if (*((unsigned int *)t3) != 0)
        goto LAB220;

LAB221:    t12 = (t23 + 4);
    t15 = *((unsigned int *)t23);
    t16 = *((unsigned int *)t12);
    t17 = (t15 || t16);
    if (t17 > 0)
        goto LAB222;

LAB223:    t18 = *((unsigned int *)t23);
    t19 = (~(t18));
    t20 = *((unsigned int *)t12);
    t21 = (t19 || t20);
    if (t21 > 0)
        goto LAB224;

LAB225:    if (*((unsigned int *)t12) > 0)
        goto LAB226;

LAB227:    if (*((unsigned int *)t23) > 0)
        goto LAB228;

LAB229:    memcpy(t4, t14, 8);

LAB230:    t24 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t24, t4, 0, 0, 32, 0LL);
    goto LAB113;

LAB81:    xsi_set_current_line(47, ng0);
    t3 = (t0 + 1528U);
    t5 = *((char **)t3);
    memset(t23, 0, 8);
    t3 = (t5 + 4);
    t7 = *((unsigned int *)t3);
    t8 = (~(t7));
    t9 = *((unsigned int *)t5);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB231;

LAB232:    if (*((unsigned int *)t3) != 0)
        goto LAB233;

LAB234:    t12 = (t23 + 4);
    t15 = *((unsigned int *)t23);
    t16 = *((unsigned int *)t12);
    t17 = (t15 || t16);
    if (t17 > 0)
        goto LAB235;

LAB236:    t18 = *((unsigned int *)t23);
    t19 = (~(t18));
    t20 = *((unsigned int *)t12);
    t21 = (t19 || t20);
    if (t21 > 0)
        goto LAB237;

LAB238:    if (*((unsigned int *)t12) > 0)
        goto LAB239;

LAB240:    if (*((unsigned int *)t23) > 0)
        goto LAB241;

LAB242:    memcpy(t4, t14, 8);

LAB243:    t24 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t24, t4, 0, 0, 32, 0LL);
    goto LAB113;

LAB83:    xsi_set_current_line(48, ng0);
    t3 = (t0 + 1528U);
    t5 = *((char **)t3);
    memset(t23, 0, 8);
    t3 = (t5 + 4);
    t7 = *((unsigned int *)t3);
    t8 = (~(t7));
    t9 = *((unsigned int *)t5);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB244;

LAB245:    if (*((unsigned int *)t3) != 0)
        goto LAB246;

LAB247:    t12 = (t23 + 4);
    t15 = *((unsigned int *)t23);
    t16 = *((unsigned int *)t12);
    t17 = (t15 || t16);
    if (t17 > 0)
        goto LAB248;

LAB249:    t18 = *((unsigned int *)t23);
    t19 = (~(t18));
    t20 = *((unsigned int *)t12);
    t21 = (t19 || t20);
    if (t21 > 0)
        goto LAB250;

LAB251:    if (*((unsigned int *)t12) > 0)
        goto LAB252;

LAB253:    if (*((unsigned int *)t23) > 0)
        goto LAB254;

LAB255:    memcpy(t4, t14, 8);

LAB256:    t24 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t24, t4, 0, 0, 32, 0LL);
    goto LAB113;

LAB85:    xsi_set_current_line(49, ng0);
    t3 = ((char*)((ng36)));
    t5 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t5, t3, 0, 0, 32, 0LL);
    goto LAB113;

LAB87:    xsi_set_current_line(50, ng0);
    t3 = ((char*)((ng4)));
    t5 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t5, t3, 0, 0, 32, 0LL);
    goto LAB113;

LAB89:    xsi_set_current_line(51, ng0);
    t3 = ((char*)((ng7)));
    t5 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t5, t3, 0, 0, 32, 0LL);
    goto LAB113;

LAB91:    xsi_set_current_line(52, ng0);
    t3 = ((char*)((ng10)));
    t5 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t5, t3, 0, 0, 32, 0LL);
    goto LAB113;

LAB93:    xsi_set_current_line(53, ng0);
    t3 = ((char*)((ng13)));
    t5 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t5, t3, 0, 0, 32, 0LL);
    goto LAB113;

LAB95:    xsi_set_current_line(54, ng0);
    t3 = ((char*)((ng16)));
    t5 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t5, t3, 0, 0, 32, 0LL);
    goto LAB113;

LAB97:    xsi_set_current_line(55, ng0);
    t3 = ((char*)((ng19)));
    t5 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t5, t3, 0, 0, 32, 0LL);
    goto LAB113;

LAB99:    xsi_set_current_line(56, ng0);
    t3 = ((char*)((ng22)));
    t5 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t5, t3, 0, 0, 32, 0LL);
    goto LAB113;

LAB101:    xsi_set_current_line(57, ng0);
    t3 = ((char*)((ng25)));
    t5 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t5, t3, 0, 0, 32, 0LL);
    goto LAB113;

LAB103:    xsi_set_current_line(58, ng0);
    t3 = ((char*)((ng28)));
    t5 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t5, t3, 0, 0, 32, 0LL);
    goto LAB113;

LAB105:    xsi_set_current_line(59, ng0);
    t3 = ((char*)((ng31)));
    t5 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t5, t3, 0, 0, 32, 0LL);
    goto LAB113;

LAB107:    xsi_set_current_line(60, ng0);
    t3 = ((char*)((ng34)));
    t5 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t5, t3, 0, 0, 32, 0LL);
    goto LAB113;

LAB109:    xsi_set_current_line(61, ng0);
    t3 = (t0 + 1528U);
    t5 = *((char **)t3);
    memset(t23, 0, 8);
    t3 = (t5 + 4);
    t7 = *((unsigned int *)t3);
    t8 = (~(t7));
    t9 = *((unsigned int *)t5);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB257;

LAB258:    if (*((unsigned int *)t3) != 0)
        goto LAB259;

LAB260:    t12 = (t23 + 4);
    t15 = *((unsigned int *)t23);
    t16 = *((unsigned int *)t12);
    t17 = (t15 || t16);
    if (t17 > 0)
        goto LAB261;

LAB262:    t18 = *((unsigned int *)t23);
    t19 = (~(t18));
    t20 = *((unsigned int *)t12);
    t21 = (t19 || t20);
    if (t21 > 0)
        goto LAB263;

LAB264:    if (*((unsigned int *)t12) > 0)
        goto LAB265;

LAB266:    if (*((unsigned int *)t23) > 0)
        goto LAB267;

LAB268:    memcpy(t4, t14, 8);

LAB269:    t24 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t24, t4, 0, 0, 32, 0LL);
    goto LAB113;

LAB114:    *((unsigned int *)t102) = 1;
    goto LAB117;

LAB116:    t108 = (t102 + 4);
    *((unsigned int *)t102) = 1;
    *((unsigned int *)t108) = 1;
    goto LAB117;

LAB118:    t113 = ((char*)((ng3)));
    goto LAB119;

LAB120:    t118 = ((char*)((ng4)));
    goto LAB121;

LAB122:    xsi_vlog_unsigned_bit_combine(t101, 32, t113, 32, t118, 32);
    goto LAB126;

LAB124:    memcpy(t101, t113, 8);
    goto LAB126;

LAB127:    *((unsigned int *)t23) = 1;
    goto LAB130;

LAB129:    t6 = (t23 + 4);
    *((unsigned int *)t23) = 1;
    *((unsigned int *)t6) = 1;
    goto LAB130;

LAB131:    t13 = ((char*)((ng6)));
    goto LAB132;

LAB133:    t14 = ((char*)((ng7)));
    goto LAB134;

LAB135:    xsi_vlog_unsigned_bit_combine(t4, 32, t13, 32, t14, 32);
    goto LAB139;

LAB137:    memcpy(t4, t13, 8);
    goto LAB139;

LAB140:    *((unsigned int *)t23) = 1;
    goto LAB143;

LAB142:    t6 = (t23 + 4);
    *((unsigned int *)t23) = 1;
    *((unsigned int *)t6) = 1;
    goto LAB143;

LAB144:    t13 = ((char*)((ng9)));
    goto LAB145;

LAB146:    t14 = ((char*)((ng10)));
    goto LAB147;

LAB148:    xsi_vlog_unsigned_bit_combine(t4, 32, t13, 32, t14, 32);
    goto LAB152;

LAB150:    memcpy(t4, t13, 8);
    goto LAB152;

LAB153:    *((unsigned int *)t23) = 1;
    goto LAB156;

LAB155:    t6 = (t23 + 4);
    *((unsigned int *)t23) = 1;
    *((unsigned int *)t6) = 1;
    goto LAB156;

LAB157:    t13 = ((char*)((ng12)));
    goto LAB158;

LAB159:    t14 = ((char*)((ng13)));
    goto LAB160;

LAB161:    xsi_vlog_unsigned_bit_combine(t4, 32, t13, 32, t14, 32);
    goto LAB165;

LAB163:    memcpy(t4, t13, 8);
    goto LAB165;

LAB166:    *((unsigned int *)t23) = 1;
    goto LAB169;

LAB168:    t6 = (t23 + 4);
    *((unsigned int *)t23) = 1;
    *((unsigned int *)t6) = 1;
    goto LAB169;

LAB170:    t13 = ((char*)((ng15)));
    goto LAB171;

LAB172:    t14 = ((char*)((ng16)));
    goto LAB173;

LAB174:    xsi_vlog_unsigned_bit_combine(t4, 32, t13, 32, t14, 32);
    goto LAB178;

LAB176:    memcpy(t4, t13, 8);
    goto LAB178;

LAB179:    *((unsigned int *)t23) = 1;
    goto LAB182;

LAB181:    t6 = (t23 + 4);
    *((unsigned int *)t23) = 1;
    *((unsigned int *)t6) = 1;
    goto LAB182;

LAB183:    t13 = ((char*)((ng18)));
    goto LAB184;

LAB185:    t14 = ((char*)((ng19)));
    goto LAB186;

LAB187:    xsi_vlog_unsigned_bit_combine(t4, 32, t13, 32, t14, 32);
    goto LAB191;

LAB189:    memcpy(t4, t13, 8);
    goto LAB191;

LAB192:    *((unsigned int *)t23) = 1;
    goto LAB195;

LAB194:    t6 = (t23 + 4);
    *((unsigned int *)t23) = 1;
    *((unsigned int *)t6) = 1;
    goto LAB195;

LAB196:    t13 = ((char*)((ng21)));
    goto LAB197;

LAB198:    t14 = ((char*)((ng22)));
    goto LAB199;

LAB200:    xsi_vlog_unsigned_bit_combine(t4, 32, t13, 32, t14, 32);
    goto LAB204;

LAB202:    memcpy(t4, t13, 8);
    goto LAB204;

LAB205:    *((unsigned int *)t23) = 1;
    goto LAB208;

LAB207:    t6 = (t23 + 4);
    *((unsigned int *)t23) = 1;
    *((unsigned int *)t6) = 1;
    goto LAB208;

LAB209:    t13 = ((char*)((ng24)));
    goto LAB210;

LAB211:    t14 = ((char*)((ng25)));
    goto LAB212;

LAB213:    xsi_vlog_unsigned_bit_combine(t4, 32, t13, 32, t14, 32);
    goto LAB217;

LAB215:    memcpy(t4, t13, 8);
    goto LAB217;

LAB218:    *((unsigned int *)t23) = 1;
    goto LAB221;

LAB220:    t6 = (t23 + 4);
    *((unsigned int *)t23) = 1;
    *((unsigned int *)t6) = 1;
    goto LAB221;

LAB222:    t13 = ((char*)((ng27)));
    goto LAB223;

LAB224:    t14 = ((char*)((ng28)));
    goto LAB225;

LAB226:    xsi_vlog_unsigned_bit_combine(t4, 32, t13, 32, t14, 32);
    goto LAB230;

LAB228:    memcpy(t4, t13, 8);
    goto LAB230;

LAB231:    *((unsigned int *)t23) = 1;
    goto LAB234;

LAB233:    t6 = (t23 + 4);
    *((unsigned int *)t23) = 1;
    *((unsigned int *)t6) = 1;
    goto LAB234;

LAB235:    t13 = ((char*)((ng30)));
    goto LAB236;

LAB237:    t14 = ((char*)((ng31)));
    goto LAB238;

LAB239:    xsi_vlog_unsigned_bit_combine(t4, 32, t13, 32, t14, 32);
    goto LAB243;

LAB241:    memcpy(t4, t13, 8);
    goto LAB243;

LAB244:    *((unsigned int *)t23) = 1;
    goto LAB247;

LAB246:    t6 = (t23 + 4);
    *((unsigned int *)t23) = 1;
    *((unsigned int *)t6) = 1;
    goto LAB247;

LAB248:    t13 = ((char*)((ng33)));
    goto LAB249;

LAB250:    t14 = ((char*)((ng34)));
    goto LAB251;

LAB252:    xsi_vlog_unsigned_bit_combine(t4, 32, t13, 32, t14, 32);
    goto LAB256;

LAB254:    memcpy(t4, t13, 8);
    goto LAB256;

LAB257:    *((unsigned int *)t23) = 1;
    goto LAB260;

LAB259:    t6 = (t23 + 4);
    *((unsigned int *)t23) = 1;
    *((unsigned int *)t6) = 1;
    goto LAB260;

LAB261:    t13 = ((char*)((ng49)));
    goto LAB262;

LAB263:    t14 = ((char*)((ng36)));
    goto LAB264;

LAB265:    xsi_vlog_unsigned_bit_combine(t4, 32, t13, 32, t14, 32);
    goto LAB269;

LAB267:    memcpy(t4, t13, 8);
    goto LAB269;

LAB270:    xsi_set_current_line(67, ng0);

LAB273:    xsi_set_current_line(68, ng0);
    t13 = (t0 + 2408);
    t14 = (t13 + 56U);
    t24 = *((char **)t14);
    memset(t23, 0, 8);
    t30 = (t24 + 4);
    t15 = *((unsigned int *)t30);
    t16 = (~(t15));
    t17 = *((unsigned int *)t24);
    t18 = (t17 & t16);
    t19 = (t18 & 1U);
    if (t19 != 0)
        goto LAB277;

LAB275:    if (*((unsigned int *)t30) == 0)
        goto LAB274;

LAB276:    t31 = (t23 + 4);
    *((unsigned int *)t23) = 1;
    *((unsigned int *)t31) = 1;

LAB277:    t37 = (t23 + 4);
    t38 = (t24 + 4);
    t20 = *((unsigned int *)t24);
    t21 = (~(t20));
    *((unsigned int *)t23) = t21;
    *((unsigned int *)t37) = 0;
    if (*((unsigned int *)t38) != 0)
        goto LAB279;

LAB278:    t28 = *((unsigned int *)t23);
    *((unsigned int *)t23) = (t28 & 1U);
    t29 = *((unsigned int *)t37);
    *((unsigned int *)t37) = (t29 & 1U);
    t44 = (t0 + 2408);
    xsi_vlogvar_wait_assign_value(t44, t23, 0, 0, 1, 0LL);
    xsi_set_current_line(69, ng0);
    t2 = (t0 + 2568);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = ((char*)((ng47)));
    memset(t4, 0, 8);
    xsi_vlog_unsigned_minus(t4, 32, t5, 32, t6, 32);
    t12 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t12, t4, 0, 0, 32, 0LL);
    goto LAB272;

LAB274:    *((unsigned int *)t23) = 1;
    goto LAB277;

LAB279:    t22 = *((unsigned int *)t23);
    t25 = *((unsigned int *)t38);
    *((unsigned int *)t23) = (t22 | t25);
    t26 = *((unsigned int *)t37);
    t27 = *((unsigned int *)t38);
    *((unsigned int *)t37) = (t26 | t27);
    goto LAB278;

}


extern void work_m_00000000003527663302_3819181035_init()
{
	static char *pe[] = {(void *)Always_27_0};
	xsi_register_didat("work_m_00000000003527663302_3819181035", "isim/testclock_isim_beh.exe.sim/work/m_00000000003527663302_3819181035.didat");
	xsi_register_executes(pe);
}
